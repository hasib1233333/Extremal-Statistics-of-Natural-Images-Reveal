# Supplementary Code and Data

This archive contains the complete, runnable source code and raw experimental
results for "Extremal Statistics of Natural Images Reveal Blur Kernel Scale:
A Self-Calibrating, Training-Free Theory for Blind Deconvolution".

## Contents

- `src/core.py` — dark-channel statistic, kernel generators, EVT calibration,
  self-calibrating estimator, baseline estimators, metrics.
- `src/deconv.py` — Richardson-Lucy non-blind deconvolution and assumed-kernel
  construction used in the downstream experiment.
- `src/run_kernel_size_experiment.py` — main upstream radius-estimation
  experiment driver (run once per dataset: Set14, BSD100, Urban100, CBSD68).
- `src/run_downstream_experiment.py` — downstream deconvolution-quality
  experiment driver.
- `src/make_figures.py`, `src/make_tables.py` — regenerate all paper figures
  and LaTeX tables from the raw result CSVs.
- `results/kernel_size_*.csv` — raw per-instance upstream results (6432 rows
  total across four datasets).
- `results/downstream_deconv.csv` — raw per-instance downstream results (216
  rows).
- `results/calib_curve.json`, `results/probe_sensitivity.json` — calibration
  curve and probe-strength sensitivity sweep data used for Figures 1 and 5.

## Reproducing

Datasets are fetched fresh from public GitHub mirrors (see paper for URLs;
Set5/Set14/BSD100/Urban100 from the SelfExSR repository, CBSD68 from its own
repository) into a `data/` folder, then:

```bash
python3 src/run_kernel_size_experiment.py Set14 results/kernel_size_Set14.csv
python3 src/run_kernel_size_experiment.py BSD100 results/kernel_size_BSD100.csv
python3 src/run_kernel_size_experiment.py Urban100 results/kernel_size_Urban100.csv
python3 src/run_kernel_size_experiment.py CBSD68 results/kernel_size_CBSD68.csv
python3 src/run_downstream_experiment.py results/downstream_deconv.csv
python3 src/make_figures.py
python3 src/make_tables.py
```

Random seeds are fixed throughout for reproducibility.
