import json

with open('/home/claude/project/results/cross_domain.json') as f:
    data = json.load(f)

rows = [
    ('Medical (retina fundus)', 'Medical (retina)', 'Poor transfer'),
    ('Medical/microscopy (immunohistochemistry)', 'Medical (immunohistochemistry)', 'Good transfer'),
    ('Microscopy (cell)', 'Microscopy (cell)', 'Poor transfer'),
    ('Astronomical (Hubble Deep Field)', 'Astronomical (hubble_deep_field)', 'Moderate transfer'),
    ('Astronomical (lunar surface)', 'Astronomical (moon)', 'Moderate transfer'),
]

lines = []
lines.append(r'\begin{tabular}{lcl}')
lines.append(r'\toprule')
lines.append(r'Domain (image) & MAE (px), natural-image constants & Transfer quality \\')
lines.append(r'\midrule')
for label, key, interp in rows:
    mae = data[key]
    lines.append(f'{label} & {mae:.2f} & {interp} \\\\')
lines.append(r'\bottomrule')
lines.append(r'\end{tabular}')

with open('/home/claude/project/manuscript/table8.tex', 'w') as f:
    f.write('\n'.join(lines) + '\n')

print('\n'.join(lines))
