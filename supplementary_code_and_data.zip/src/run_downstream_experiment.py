"""
Downstream deconvolution-quality experiment.
Reuses the radius estimates already computed in results/kernel_size_*.csv;
for a stratified sample of instances, reconstructs the assumed kernel from
each method's estimate and runs Richardson-Lucy, measuring final PSNR/SSIM
and kernel MSE against the true kernel and against the oracle-radius result.
"""
import sys, os, glob, time
import numpy as np
import pandas as pd
from PIL import Image
from skimage.transform import resize

sys.path.insert(0, os.path.dirname(__file__))
import core
import deconv
import run_kernel_size_experiment as rkse

METHODS = ['r_true', 'r_evt', 'r_selfcal', 'r_fixed', 'r_autocorr', 'r_spectral', 'r_svr']
IMAGES_PER_DATASET = 6
RADII_STRATA = {
    'gaussian': [2, 5, 10],
    'disk': [2, 5, 10],
    'motion': [6, 15, 30],
}


def main():
    out_csv = sys.argv[1] if len(sys.argv) > 1 else 'results/downstream_deconv.csv'
    rng = np.random.default_rng(777)

    rows = []
    for dataset_name in ['Set14', 'BSD100', 'Urban100', 'CBSD68']:
        est_df = pd.read_csv(f'results/kernel_size_{dataset_name}.csv')
        est_df = est_df[est_df.noise == 0.0]
        images = sorted(est_df.image.unique())
        sel_images = rng.choice(images, size=min(IMAGES_PER_DATASET, len(images)), replace=False)

        for img_id in sel_images:
            fpath = [f for f in glob.glob(rkse.DATASET_PATHS[dataset_name]) if os.path.basename(f) == img_id]
            if not fpath:
                continue
            sharp = rkse.load_resized(fpath[0], dim=200)  # smaller for RL speed

            for ktype, radii in RADII_STRATA.items():
                for target_param in radii:
                    sub = est_df[(est_df.image == img_id) & (est_df.kernel_type == ktype) &
                                 (est_df.kernel_param == target_param)]
                    if len(sub) == 0:
                        continue
                    row_data = sub.iloc[0]
                    r_true = row_data['r_true']

                    k_true = deconv.assumed_kernel_from_radius(r_true, ktype)
                    blurry = core.apply_blur(sharp, k_true, noise_sigma=0.0)
                    psnr_blurry = core.psnr(blurry, sharp)
                    ssim_blurry = core.ssim(blurry, sharp)

                    result_row = dict(dataset=dataset_name, image=img_id, kernel_type=ktype,
                                       kernel_param=target_param, r_true=r_true,
                                       psnr_blurry=psnr_blurry, ssim_blurry=ssim_blurry)

                    for method in METHODS:
                        if method == 'r_true':
                            r_hat = r_true
                        else:
                            r_hat = row_data[method]
                        k_assumed = deconv.assumed_kernel_from_radius(r_hat, ktype)
                        restored = deconv.richardson_lucy(blurry, k_assumed, n_iter=25)
                        result_row[f'psnr_{method}'] = core.psnr(restored, sharp)
                        result_row[f'ssim_{method}'] = core.ssim(restored, sharp)
                        result_row[f'kmse_{method}'] = deconv.kernel_mse(k_assumed, k_true)
                        result_row[f'rhat_{method}'] = r_hat

                    rows.append(result_row)
            print(f'[{dataset_name}] {img_id} done, total rows so far: {len(rows)}')

    df = pd.DataFrame(rows)
    df.to_csv(out_csv, index=False)
    print(f'Saved {len(df)} rows to {out_csv}')


if __name__ == '__main__':
    main()
