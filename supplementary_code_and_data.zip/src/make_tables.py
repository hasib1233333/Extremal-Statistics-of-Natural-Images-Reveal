import numpy as np
import pandas as pd
from scipy import stats

T = '/home/claude/project/manuscript/tables'
full = pd.read_csv('/home/claude/project/results/kernel_size_ALL.csv')
downstream = pd.read_csv('/home/claude/project/results/downstream_deconv.csv')

METHOD_ORDER = ['r_selfcal', 'r_evt', 'r_fixed', 'r_autocorr', 'r_spectral', 'r_svr']
METHOD_NAMES = {
    'r_selfcal': 'Self-Calibrating EVT (ours)',
    'r_evt': 'Naive population-$\\Delta_0$ EVT',
    'r_fixed': 'Fixed default ($r{=}3$)',
    'r_autocorr': 'Gradient autocorrelation',
    'r_spectral': 'Spectral-slope cutoff',
    'r_svr': 'HOG+SVR (supervised)',
}

# ---------------- Table 1: dataset summary ----------------
with open(f'{T}/table1.tex', 'w') as f:
    f.write(r"""\begin{tabular}{lccl}
\toprule
Dataset & \# Images (eval.) & Role & Source / notes \\
\midrule
Set5 & 5 & Calibration only & Held out; used solely to fit $\tau,\gamma$ and probe strength \\
Set14 + BSD100$_{\text{calib}}$ & 14 + 20 & Calibration (BSD100 split) & Disjoint from all evaluation splits \\
Set14 & 14 & Evaluation & Classic diverse-content SR/restoration benchmark \\
BSD100 & 80 & Evaluation & Berkeley Segmentation Dataset test images (calib.\ split excluded) \\
Urban100 & 100 & Evaluation & Urban/architectural scenes, strong self-similar structure \\
CBSD68 & 68 & Evaluation & Color BSD68 (Roth \& Black / Zoran \& Weiss subset) \\
\bottomrule
\end{tabular}
""")

# ---------------- Table 2: main upstream accuracy ----------------
rows = []
for m in METHOD_ORDER:
    mae = np.mean(np.abs(full[m] - full.r_true))
    rmse = np.sqrt(np.mean((full[m] - full.r_true) ** 2))
    pear = stats.pearsonr(full[m], full.r_true)[0] if full[m].std() > 0 else float('nan')
    rows.append((m, mae, rmse, pear))
best_mae = min(r[1] for r in rows)
best_pear = max(r[3] for r in rows if not np.isnan(r[3]))

with open(f'{T}/table2.tex', 'w') as f:
    f.write(r"\begin{tabular}{lccc}" + "\n")
    f.write(r"\toprule" + "\n")
    f.write(r"Method & MAE (px) $\downarrow$ & RMSE (px) $\downarrow$ & Pearson $r$ $\uparrow$ \\" + "\n")
    f.write(r"\midrule" + "\n")
    for m, mae, rmse, pear in rows:
        mae_s = f"\\textbf{{{mae:.3f}}}" if abs(mae - best_mae) < 1e-9 else f"{mae:.3f}"
        pear_s = "---" if np.isnan(pear) else (f"\\textbf{{{pear:.3f}}}" if abs(pear - best_pear) < 1e-9 else f"{pear:.3f}")
        f.write(f"{METHOD_NAMES[m]} & {mae_s} & {rmse:.3f} & {pear_s} \\\\\n")
    f.write(r"\bottomrule" + "\n")
    f.write(r"\end{tabular}" + "\n")

# ---------------- Table 3: per-kernel-type / per-dataset MAE ----------------
with open(f'{T}/table3.tex', 'w') as f:
    f.write(r"\begin{tabular}{llcccccc}" + "\n")
    f.write(r"\toprule" + "\n")
    f.write(r"Dataset & Kernel & " + " & ".join(METHOD_NAMES[m].split(' (')[0] for m in METHOD_ORDER) + r" \\" + "\n")
    f.write(r"\midrule" + "\n")
    for ds in ['Set14', 'BSD100', 'Urban100', 'CBSD68']:
        for kt in ['gaussian', 'disk', 'motion']:
            sub = full[(full.dataset == ds) & (full.kernel_type == kt)]
            vals = [np.mean(np.abs(sub[m] - sub.r_true)) for m in METHOD_ORDER]
            best_idx = int(np.argmin(vals))
            vals_s = [f"\\textbf{{{v:.2f}}}" if i == best_idx else f"{v:.2f}" for i, v in enumerate(vals)]
            f.write(f"{ds} & {kt} & " + " & ".join(vals_s) + r" \\" + "\n")
    f.write(r"\bottomrule" + "\n")
    f.write(r"\end{tabular}" + "\n")

# ---------------- Table 4: ablation + significance ----------------
err_self = np.abs(full.r_selfcal - full.r_true)
err_evt = np.abs(full.r_evt - full.r_true)
stat, p_ablation = stats.wilcoxon(err_self, err_evt)
reduction = 100 * (1 - err_self.mean() / err_evt.mean())

sig_rows = []
for m in ['r_fixed', 'r_autocorr', 'r_spectral', 'r_svr']:
    err_b = np.abs(full[m] - full.r_true)
    stat, p = stats.wilcoxon(err_self, err_b)
    diff = (err_self - err_b).mean()
    sig_rows.append((m, diff, p))

with open(f'{T}/table4.tex', 'w') as f:
    f.write(r"\begin{tabular}{lccc}" + "\n")
    f.write(r"\toprule" + "\n")
    f.write(r"Comparison & Mean MAE difference (px) & Wilcoxon $p$ & Effect \\" + "\n")
    f.write(r"\midrule" + "\n")
    f.write(f"Self-cal.\\ vs.\\ naive EVT (ablation) & {-reduction/100*err_evt.mean():.3f} & "
            f"{p_ablation:.1e} & {reduction:.1f}\\% error reduction \\\\\n")
    f.write(r"\midrule" + "\n")
    for m, diff, p in sig_rows:
        effect = "ours lower error" if diff < 0 else "baseline lower error"
        f.write(f"Self-cal.\\ vs.\\ {METHOD_NAMES[m]} & {diff:+.3f} & {p:.1e} & {effect} \\\\\n")
    f.write(r"\bottomrule" + "\n")
    f.write(r"\end{tabular}" + "\n")

# ---------------- Table 5: downstream deconvolution quality ----------------
dmethods = ['r_true', 'r_selfcal', 'r_evt', 'r_fixed', 'r_autocorr', 'r_spectral', 'r_svr']
dnames = {'r_true': 'Oracle (true $r$)', **METHOD_NAMES}
with open(f'{T}/table5.tex', 'w') as f:
    f.write(r"\begin{tabular}{lcccc}" + "\n")
    f.write(r"\toprule" + "\n")
    f.write(r"Kernel-size source & PSNR (dB) & SSIM & $p$ vs.\ ours (PSNR) & $p$ vs.\ ours (SSIM) \\" + "\n")
    f.write(r"\midrule" + "\n")
    f.write(f"Blurry (no deconvolution) & {downstream.psnr_blurry.mean():.2f} & "
            f"{downstream.ssim_blurry.mean():.3f} & --- & --- \\\\\n")
    f.write(r"\midrule" + "\n")
    for m in dmethods:
        psnr_v = downstream[f'psnr_{m}'].mean()
        ssim_v = downstream[f'ssim_{m}'].mean()
        if m == 'r_selfcal':
            p_psnr = p_ssim = '---'
        else:
            _, pp = stats.wilcoxon(downstream['psnr_r_selfcal'], downstream[f'psnr_{m}'])
            _, ps = stats.wilcoxon(downstream['ssim_r_selfcal'], downstream[f'ssim_{m}'])
            p_psnr, p_ssim = f'{pp:.1e}', f'{ps:.1e}'
        label = dnames[m] if m != 'r_selfcal' else 'Self-Calibrating EVT (ours)'
        f.write(f"{label} & {psnr_v:.2f} & {ssim_v:.3f} & {p_psnr} & {p_ssim} \\\\\n")
    f.write(r"\bottomrule" + "\n")
    f.write(r"\end{tabular}" + "\n")

# ---------------- Table 6: computational cost ----------------
with open(f'{T}/table6.tex', 'w') as f:
    f.write(r"\begin{tabular}{lc}" + "\n")
    f.write(r"\toprule" + "\n")
    f.write(r"Method & Mean wall-clock time per image (ms) \\" + "\n")
    f.write(r"\midrule" + "\n")
    tmap = {'r_evt': 't_evt', 'r_selfcal': 't_selfcal', 'r_fixed': 't_fixed',
            'r_autocorr': 't_autocorr', 'r_spectral': 't_spectral', 'r_svr': 't_svr'}
    for m in METHOD_ORDER:
        t_ms = full[tmap[m]].mean() * 1000
        f.write(f"{METHOD_NAMES[m]} & {t_ms:.2f} \\\\\n")
    f.write(r"\bottomrule" + "\n")
    f.write(r"\end{tabular}" + "\n")

# ---------------- Table 7: robustness to noise ----------------
with open(f'{T}/table7.tex', 'w') as f:
    f.write(r"\begin{tabular}{lcc}" + "\n")
    f.write(r"\toprule" + "\n")
    f.write(r"Method & MAE, $\sigma_{noise}{=}0$ & MAE, $\sigma_{noise}{=}0.02$ \\" + "\n")
    f.write(r"\midrule" + "\n")
    for m in METHOD_ORDER:
        m0 = np.mean(np.abs(full[full.noise == 0.0][m] - full[full.noise == 0.0].r_true))
        m1 = np.mean(np.abs(full[full.noise == 0.02][m] - full[full.noise == 0.02].r_true))
        f.write(f"{METHOD_NAMES[m]} & {m0:.3f} & {m1:.3f} \\\\\n")
    f.write(r"\bottomrule" + "\n")
    f.write(r"\end{tabular}" + "\n")

print("All tables written to", T)
for i in range(1, 8):
    print(f'--- table{i}.tex ---')
    print(open(f'{T}/table{i}.tex').read())
