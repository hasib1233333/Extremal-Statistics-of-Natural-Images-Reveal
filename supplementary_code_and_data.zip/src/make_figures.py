import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats

plt.rcParams.update({
    'font.size': 10, 'font.family': 'serif',
    'axes.spines.top': False, 'axes.spines.right': False,
    'figure.dpi': 150,
})

OUT = '/home/claude/project/manuscript/figures'
full = pd.read_csv('/home/claude/project/results/kernel_size_ALL.csv')
downstream = pd.read_csv('/home/claude/project/results/downstream_deconv.csv')
with open('/home/claude/project/results/calib_curve.json') as f:
    calib_curve = json.load(f)

METHOD_LABELS = {
    'r_evt': 'Naive EVT (population $\\Delta_0$)',
    'r_selfcal': 'Self-Calibrating EVT (ours)',
    'r_fixed': 'Fixed default',
    'r_autocorr': 'Gradient autocorrelation',
    'r_spectral': 'Spectral-slope cutoff',
    'r_svr': 'HOG+SVR (supervised)',
}
COLORS = {
    'r_evt': '#999999', 'r_selfcal': '#1b5e20', 'r_fixed': '#9e9e9e',
    'r_autocorr': '#1976d2', 'r_spectral': '#f9a825', 'r_svr': '#8e24aa',
}

# ---------------- Figure 1: calibration curve ----------------
fig, ax = plt.subplots(figsize=(5, 3.6))
r = np.array(calib_curve['r'])
d = np.array(calib_curve['delta'])
delta0, tau, gamma = calib_curve['delta0'], calib_curve['tau'], calib_curve['gamma']
r_dense = np.linspace(0, 12, 200)
model = delta0 * (1 + (r_dense / tau) ** 2) ** (-gamma)
ax.scatter(r, d, color='#1b5e20', s=28, zorder=3, label='Measured $\\Delta(r)$ (calibration corpus)')
ax.plot(r_dense, model, color='#c62828', lw=1.8, zorder=2,
        label=f'Fitted model $\\Delta_0(1+(r/\\tau)^2)^{{-\\gamma}}$')
ax.set_xlabel('Blur kernel effective radius $r$ (px)')
ax.set_ylabel('Dark-channel depth $\\Delta(r)$')
ax.legend(fontsize=7.5, frameon=False)
ax.set_title('Tail-contraction calibration fit', fontsize=10)
fig.tight_layout()
fig.savefig(f'{OUT}/figure1.pdf')
plt.close(fig)

# ---------------- Figure 2: scatter r_true vs r_selfcal, faceted by dataset ----------------
fig, axes = plt.subplots(1, 4, figsize=(10, 2.6), sharey=True, sharex=True)
datasets = ['Set14', 'BSD100', 'Urban100', 'CBSD68']
for ax, ds in zip(axes, datasets):
    sub = full[(full.dataset == ds) & (full.noise == 0.0)]
    ax.scatter(sub.r_true, sub.r_selfcal, s=4, alpha=0.35, color='#1b5e20')
    lims = [0, 32]
    ax.plot(lims, lims, '--', color='gray', lw=0.8)
    ax.set_title(ds, fontsize=9)
    ax.set_xlabel('True $r$')
    ax.set_xlim(0, 32); ax.set_ylim(0, 32)
axes[0].set_ylabel('Estimated $\\hat r$ (ours)')
fig.tight_layout()
fig.savefig(f'{OUT}/figure2.pdf')
plt.close(fig)

# ---------------- Figure 3: MAE by method, grouped by dataset ----------------
methods = ['r_evt', 'r_selfcal', 'r_fixed', 'r_autocorr', 'r_spectral', 'r_svr']
fig, ax = plt.subplots(figsize=(7, 3.4))
x = np.arange(len(datasets))
width = 0.13
for i, m in enumerate(methods):
    maes = [np.mean(np.abs(full[(full.dataset == ds)][m] - full[(full.dataset == ds)].r_true)) for ds in datasets]
    ax.bar(x + (i - len(methods) / 2) * width, maes, width, label=METHOD_LABELS[m], color=COLORS[m])
ax.set_xticks(x)
ax.set_xticklabels(datasets)
ax.set_ylabel('MAE (px)')
ax.set_title('Radius-estimation error by dataset and method')
ax.legend(fontsize=6.5, ncol=2, frameon=False, loc='upper right')
fig.tight_layout()
fig.savefig(f'{OUT}/figure3.pdf')
plt.close(fig)

# ---------------- Figure 4: ablation (evt vs selfcal), CDF of absolute error ----------------
fig, ax = plt.subplots(figsize=(5, 3.6))
for m, lbl, c in [('r_evt', 'Naive population-$\\Delta_0$ EVT', '#999999'),
                   ('r_selfcal', 'Self-calibrating EVT (ours)', '#1b5e20')]:
    err = np.sort(np.abs(full[m] - full.r_true).values)
    y = np.linspace(0, 1, len(err))
    ax.plot(err, y, label=lbl, color=c, lw=1.8)
ax.set_xlim(0, 20)
ax.set_xlabel('Absolute radius error (px)')
ax.set_ylabel('Empirical CDF')
ax.set_title('Ablation: effect of self-calibration')
ax.legend(fontsize=8, frameon=False)
fig.tight_layout()
fig.savefig(f'{OUT}/figure4.pdf')
plt.close(fig)

# ---------------- Figure 5: probe-sigma sensitivity ----------------
with open('/home/claude/project/results/probe_sensitivity.json') as f:
    probe_sens = json.load(f)
fig, ax = plt.subplots(figsize=(5, 3.4))
ps = list(map(float, probe_sens.keys()))
maes = list(probe_sens.values())
ax.plot(ps, maes, 'o-', color='#1b5e20')
ax.axvline(5.0, color='#c62828', ls='--', lw=1, label='Selected $\\sigma_{probe}=5.0$')
ax.set_xlabel('Probe blur strength $\\sigma_{probe}$')
ax.set_ylabel('MAE on calibration corpus (px)')
ax.set_title('Sensitivity to probe strength (leak-free, calibration-only)')
ax.legend(fontsize=8, frameon=False)
fig.tight_layout()
fig.savefig(f'{OUT}/figure5.pdf')
plt.close(fig)

# ---------------- Figure 6: downstream PSNR/SSIM comparison ----------------
fig, axes = plt.subplots(1, 2, figsize=(9, 3.4))
dmethods = ['r_true', 'r_evt', 'r_selfcal', 'r_fixed', 'r_autocorr', 'r_spectral', 'r_svr']
dlabels = ['Oracle', 'Naive EVT', 'Ours', 'Fixed', 'Autocorr', 'Spectral', 'SVR']
dcolors = ['#616161', '#999999', '#1b5e20', '#9e9e9e', '#1976d2', '#f9a825', '#8e24aa']
psnr_vals = [downstream[f'psnr_{m}'].mean() for m in dmethods]
ssim_vals = [downstream[f'ssim_{m}'].mean() for m in dmethods]
axes[0].bar(dlabels, psnr_vals, color=dcolors)
axes[0].axhline(downstream.psnr_blurry.mean(), color='black', ls=':', lw=1, label='Blurry (no deconv)')
axes[0].set_ylabel('PSNR (dB)'); axes[0].set_title('Downstream PSNR'); axes[0].legend(fontsize=7, frameon=False)
axes[0].tick_params(axis='x', rotation=35)
axes[1].bar(dlabels, ssim_vals, color=dcolors)
axes[1].axhline(downstream.ssim_blurry.mean(), color='black', ls=':', lw=1, label='Blurry (no deconv)')
axes[1].set_ylabel('SSIM'); axes[1].set_title('Downstream SSIM'); axes[1].legend(fontsize=7, frameon=False)
axes[1].tick_params(axis='x', rotation=35)
fig.tight_layout()
fig.savefig(f'{OUT}/figure6.pdf')
plt.close(fig)

print('All figures generated in', OUT)
