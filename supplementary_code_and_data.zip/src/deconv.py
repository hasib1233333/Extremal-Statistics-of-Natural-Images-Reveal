"""
Downstream deconvolution utilities.

We use classical, well-established Richardson-Lucy non-blind deconvolution
(guaranteed stable, non-negativity-preserving multiplicative updates) rather
than a from-scratch alternating blind optimizer. An initial from-scratch
alternating-least-squares blind scheme was implemented and empirically found
to diverge (kernel error grew monotonically across iterations even after the
standard gradient-domain stabilization from Cho & Lee 2009 / Xu & Jia 2010),
which is a known, documented hazard of naive alternating minimization for
blind deconvolution and not the object of study in this paper. Richardson-Lucy
lets us isolate exactly the question of practical interest: given only a
radius estimate (ours or a baseline's), construct the ASSUMED kernel and
measure how restoration quality depends on the accuracy of that estimate --
independent of blind kernel-refinement dynamics.
"""
import numpy as np
from scipy import ndimage
import core


def richardson_lucy(blurry, kernel, n_iter=30, eps=1e-6):
    """Classical Richardson-Lucy deconvolution (Richardson 1972; Lucy 1974).
    Uses FFT-based convolution for speed at larger kernel sizes."""
    from scipy.signal import fftconvolve
    kernel = kernel / (kernel.sum() + 1e-12)
    kernel_flipped = kernel[::-1, ::-1]
    H, W, C = blurry.shape
    latent = blurry.copy()
    for c in range(C):
        est = blurry[:, :, c].copy()
        for _ in range(n_iter):
            conv_est = fftconvolve(est, kernel, mode='same') + eps
            relative_blur = blurry[:, :, c] / conv_est
            est = est * fftconvolve(relative_blur, kernel_flipped, mode='same')
            est = np.clip(est, 0, 1)
        latent[:, :, c] = est
    return latent


def assumed_kernel_from_radius(r_hat, kernel_family, ksize_cap=41):
    """Builds the ASSUMED kernel a downstream non-blind deconvolution pipeline
    would use given only a radius estimate and a kernel family (kernel family
    is standardly assumed/known from the imaging scenario -- e.g. optical
    defocus -> disk, camera shake -> motion, generic -> Gaussian)."""
    r_hat = max(r_hat, 0.3)
    if kernel_family == 'gaussian':
        k, _ = core.gaussian_kernel(sigma=r_hat)
    elif kernel_family == 'disk':
        k, _ = core.disk_kernel(radius=r_hat)
    elif kernel_family == 'motion':
        k, _ = core.motion_kernel(length=max(r_hat * 2.6, 1.0), angle_deg=0.0)
    else:
        raise ValueError(kernel_family)
    if k.shape[0] > ksize_cap:
        k, _ = core.gaussian_kernel(sigma=r_hat, ksize=ksize_cap)
    return k


def kernel_mse(k_est, k_true):
    """Compares two (possibly differently-sized) normalized kernels by
    centering both on a common padded canvas before computing MSE."""
    size = max(k_est.shape[0], k_true.shape[0]) + 4
    size = size | 1

    def pad_center(k):
        out = np.zeros((size, size))
        h, w = k.shape
        y0 = size // 2 - h // 2
        x0 = size // 2 - w // 2
        out[y0:y0 + h, x0:x0 + w] = k
        return out

    a = pad_center(k_est)
    b = pad_center(k_true)
    return float(np.mean((a - b) ** 2))
