"""
Main experiment: kernel-size (effective-radius) estimation accuracy.
Usage: python3 run_kernel_size_experiment.py <dataset_name> <out_csv>
dataset_name in {Set14, BSD100, Urban100, CBSD68}
"""
import sys, os, glob, json, time
import numpy as np
import pandas as pd
from PIL import Image
from skimage.transform import resize

sys.path.insert(0, os.path.dirname(__file__))
import core

WORK_DIM = 256
RNG_SEED = 20260730
N_SAMPLE = {'Set14': None, 'BSD100': 40, 'Urban100': 40, 'CBSD68': 40}  # None = use all

DATASET_PATHS = {
    'Set14': 'data/selfexsr/data/Set14/image_SRF_2/*_HR.png',
    'BSD100': 'data/selfexsr/data/BSD100/image_SRF_2/*_HR.png',
    'Urban100': 'data/selfexsr/data/Urban100/image_SRF_2/*_HR.png',
    'CBSD68': 'data/cbsd68/CBSD68/original_png/*.png',
}


def load_resized(path, dim=WORK_DIM):
    im = np.array(Image.open(path).convert('RGB')).astype(np.float64) / 255.0
    scale = dim / max(im.shape[:2])
    if scale < 1.0:
        im = resize(im, (int(round(im.shape[0] * scale)), int(round(im.shape[1] * scale))),
                    anti_aliasing=True)
    return im


N_CALIB_FROM_BSD100 = 20  # held out from BSD100; excluded from BSD100 evaluation split


def get_calibration_and_svr():
    set5_files = sorted(glob.glob('data/selfexsr/data/Set5/image_SRF_2/*_HR.png'))
    bsd_all = sorted(glob.glob(DATASET_PATHS['BSD100']))
    calib_rng = np.random.default_rng(1234)  # fixed, independent of evaluation sampling rng
    calib_idx = calib_rng.choice(len(bsd_all), size=N_CALIB_FROM_BSD100, replace=False)
    bsd_calib_files = [bsd_all[i] for i in sorted(calib_idx)]
    calib_files = set5_files + bsd_calib_files
    ref_images = [load_resized(f) for f in calib_files]
    radii = [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 7, 8, 10, 12]
    blur_cache = core.build_blur_cache(ref_images, radii, kernel_family='gaussian')
    calib = core.EVTCalibration(w=5)
    calib.fit(ref_images, radii, kernel_family='gaussian', blur_cache=blur_cache)
    svr = core.HOGSVRBaseline()
    svr.fit(ref_images, radii, kernel_family='gaussian', blur_cache=blur_cache)
    return calib, svr, ref_images, set(bsd_calib_files)


def build_kernel(kernel_type, param, rng):
    if kernel_type == 'gaussian':
        k, r_eff = core.gaussian_kernel(sigma=param)
    elif kernel_type == 'disk':
        k, r_eff = core.disk_kernel(radius=param)
    elif kernel_type == 'motion':
        angle = rng.uniform(0, 180)
        k, r_eff = core.motion_kernel(length=param, angle_deg=angle)
    else:
        raise ValueError(kernel_type)
    return k, r_eff


def main():
    dataset_name = sys.argv[1]
    out_csv = sys.argv[2]
    rng = np.random.default_rng(RNG_SEED)

    print(f'[{dataset_name}] calibrating EVT model + HOG-SVR baseline on Set5 + held-out BSD100 split...')
    calib, svr, _, bsd_calib_files = get_calibration_and_svr()
    print('EVT calibration params:', calib.params())
    selfcal = core.SelfCalibratingEVT(tau=calib.tau, gamma=calib.gamma, w=5, probe_sigma=5.0)

    files = sorted(glob.glob(DATASET_PATHS[dataset_name]))
    if dataset_name == 'BSD100':
        files = [f for f in files if f not in bsd_calib_files]
        print(f'[{dataset_name}] excluded {len(bsd_calib_files)} calibration-held-out images '
              f'-> {len(files)} remain for evaluation')
    n = N_SAMPLE[dataset_name]
    if n is not None and n < len(files):
        idx = rng.choice(len(files), size=n, replace=False)
        idx.sort()
        files = [files[i] for i in idx]
    print(f'[{dataset_name}] using {len(files)} images')

    kernel_grid = {
        'gaussian': [1, 2, 3, 4, 5, 6, 8, 10],
        'disk': [1, 2, 3, 4, 5, 6, 8, 10],
        'motion': [3, 6, 9, 12, 15, 18, 24, 30],
    }
    noise_levels = [0.0, 0.02]

    rows = []
    t_start = time.time()
    n_total = len(files) * sum(len(v) for v in kernel_grid.values()) * len(noise_levels)
    counter = 0
    for fpath in files:
        img = load_resized(fpath)
        img_id = os.path.basename(fpath)
        for ktype, params in kernel_grid.items():
            for p in params:
                k, r_true = build_kernel(ktype, p, rng)
                for noise in noise_levels:
                    blurred = core.apply_blur(img, k, noise_sigma=noise, rng=rng)

                    t0 = time.time(); r_evt = calib.estimate_radius(blurred); t_evt = time.time() - t0
                    t0 = time.time(); r_selfcal = selfcal.estimate_radius(blurred); t_selfcal = time.time() - t0
                    t0 = time.time(); r_fixed = core.baseline_fixed(blurred); t_fixed = time.time() - t0
                    t0 = time.time(); r_ac = core.baseline_autocorrelation(blurred); t_ac = time.time() - t0
                    t0 = time.time(); r_spec = core.baseline_spectral_slope(blurred); t_spec = time.time() - t0
                    t0 = time.time(); r_svr = svr.estimate_radius(blurred); t_svr = time.time() - t0

                    rows.append(dict(
                        dataset=dataset_name, image=img_id, kernel_type=ktype,
                        kernel_param=p, noise=noise, r_true=r_true,
                        r_evt=r_evt, r_selfcal=r_selfcal, r_fixed=r_fixed,
                        r_autocorr=r_ac, r_spectral=r_spec, r_svr=r_svr,
                        t_evt=t_evt, t_selfcal=t_selfcal, t_fixed=t_fixed,
                        t_autocorr=t_ac, t_spectral=t_spec, t_svr=t_svr,
                    ))
                    counter += 1
        elapsed = time.time() - t_start
        print(f'[{dataset_name}] {img_id} done ({counter}/{n_total}), elapsed {elapsed:.1f}s')

    df = pd.DataFrame(rows)
    df.to_csv(out_csv, index=False)
    print(f'[{dataset_name}] saved {len(df)} rows to {out_csv}, total time {time.time()-t_start:.1f}s')

    with open(out_csv.replace('.csv', '_calib_params.json'), 'w') as f:
        json.dump(calib.params(), f, indent=2)


if __name__ == '__main__':
    main()
