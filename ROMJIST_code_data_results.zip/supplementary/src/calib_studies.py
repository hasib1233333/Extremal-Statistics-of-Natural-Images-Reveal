from common import *
import pickle, pandas as pd
from law import *
P=pickle.load(open(BASE+'new/pool.pkl','rb')); n25=P['n_set5']+P['n_calib']; N=len(P['files'])
df=pd.concat([pd.read_csv(BASE+'new/up_%s.csv'%d) for d in ['Set14','BSD100','Urban100','CBSD68']])
pk,dr=core.gaussian_kernel(sigma=PROBE_SIGMA)
rho=(df.d2/df.d1).values; rt=df.r_true.values; img=df.image.values+df.dataset.values
def mae(tau,gam,mask=None):
    rh=invert(rho,tau,gam,dr); e=np.abs(rh-rt)
    return e.mean() if mask is None else e[mask].mean()
def imgmae(tau,gam):
    rh=invert(rho,tau,gam,dr); e=pd.Series(np.abs(rh-rt)).groupby(img).mean(); return e.mean()
G=P['fam']['gaussian']
out={}
# E1 calibration size / repeated splits
rng=np.random.default_rng(2026); E1={}
for n in [3,5,10,15,25,40,65]:
    rep=1 if n==65 else 30; rs=[]
    for _ in range(rep):
        idx=rng.choice(N,size=n,replace=False)
        d0,t,g=fit_law(G['r'],G['depth'][idx].mean(0)); rs.append((t,g,imgmae(t,g)))
    a=np.array(rs); E1[n]=dict(tau_mean=a[:,0].mean(),tau_sd=a[:,0].std(),gam_mean=a[:,1].mean(),gam_sd=a[:,1].std(),
        mae_mean=a[:,2].mean(),mae_sd=a[:,2].std(),mae_min=a[:,2].min(),mae_max=a[:,2].max(),reps=rep)
out['E1']=E1
# E2 family-specific laws (fit on first 25 images, each family's curves)
def fam_fit(f,idx=range(n25)):
    F=P['fam'][f]; return fit_law(F['r'],F['depth'][list(idx)].mean(0))
const={f:fam_fit(f) for f in ['gaussian','disk','motion']}
allr=np.concatenate([P['fam'][f]['r'][1:] for f in const]); alld=np.concatenate([P['fam'][f]['depth'][:n25,1:].mean(0) for f in const])
r0=P['fam']['gaussian']['r'][:1]; d0=P['fam']['gaussian']['depth'][:n25,0].mean()
const['mixed']=fit_law(np.concatenate([r0,allr]),np.concatenate([[d0],alld]))
E2={}
for kt in ['gaussian','disk','motion']:
    m=(df.kernel_type==kt).values
    E2[kt]={k:mae(const[k][1],const[k][2],m) for k in const}
E2['constants']={k:dict(delta0=float(v[0]),tau=float(v[1]),gamma=float(v[2])) for k,v in const.items()}
out['E2']=E2
# E3 held-out radii: calibrate only on small radii
def restricted(rmax):
    m=G['r']<=rmax; return fit_law(G['r'][m],G['depth'][:n25][:,m].mean(0))
E3={}
full=fit_law(G['r'],G['depth'][:n25].mean(0))
for name,(lo,hi) in {'0-4':(0,4.3),'4-8':(4.3,8),'8+':(8,99)}.items():
    m=((rt>=lo)&(rt<hi))
    E3[name]=dict(n=int(m.sum()))
for rmax in [4.3,8.0]:
    c=restricted(rmax)
    for name,(lo,hi) in {'0-4':(0,4.3),'4-8':(4.3,8),'8+':(8,99)}.items():
        m=((rt>=lo)&(rt<hi)); E3[name]['cal_to_%.1f'%rmax]=mae(c[1],c[2],m); 
    E3['const_%.1f'%rmax]=dict(tau=float(c[1]),gamma=float(c[2]))
for name,(lo,hi) in {'0-4':(0,4.3),'4-8':(4.3,8),'8+':(8,99)}.items():
    m=((rt>=lo)&(rt<hi)); E3[name]['full']=mae(full[1],full[2],m); E3[name]['fixed']=np.abs(df.r_fixed.values-rt)[m].mean(); E3[name]['svr']=np.abs(df.r_svr.values-rt)[m].mean()
out['E3']=E3
# E4 robustness: noise, JPEG
E4={}
for nz in [0.0,0.02]:
    m=(df.noise==nz).values; E4['noise%.2f'%nz]=dict(mae=float(np.abs(df.r_selfcal-df.r_true)[m].mean()),mae_jpeg=float(np.abs(df.r_selfcal_jpeg-df.r_true)[m].mean()),fixed=float(np.abs(df.r_fixed-df.r_true)[m].mean()),svr=float(np.abs(df.r_svr-df.r_true)[m].mean()))
out['E4']=E4
# held-out law check on evaluation corpus (clean)
c=pd.DataFrame(dict(rho=rho,r=rt,kt=df.kernel_type.values,noise=df.noise.values,img=img)); c=c[c.noise==0]
tau,gam=full[1],full[2]
e=np.log(c.rho.clip(1e-6,1-1e-6))-np.log(rho_pred(c.r.values,tau,gam,dr))
L=dict(n=len(c),median=float(np.median(e)),rmse=float(np.sqrt((e**2).mean())))
L['by_family']={k:dict(median=float(np.median(e[c.kt==k])),rmse=float(np.sqrt((e[c.kt==k]**2).mean()))) for k in ['gaussian','disk','motion']}
from scipy.optimize import least_squares
def refit(f,x0):
    r=least_squares(lambda p:np.log(c.rho.clip(1e-6,1-1e-6))-f(p),x0); return r.x.tolist(),float(np.sqrt(np.mean(r.fun**2)))
L['refit_power']=refit(lambda p:np.log(rho_pred(c.r.values,p[0],p[1],dr)),[tau,gam])
L['refit_exp']=refit(lambda p:np.log(1-p[0]*(1-np.exp(-dr**2/p[1]**2/(1+c.r.values**2/p[1]**2)))),[.3,1.0])
out['law_check']=L
json.dump(out,open(BASE+'new/calib_studies.json','w'),indent=1,default=float)
print(json.dumps(out,indent=1,default=float)[:3500])
