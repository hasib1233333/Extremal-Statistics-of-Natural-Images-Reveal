import json, math, pickle, glob, numpy as np, pandas as pd
from scipy import stats
B=__import__('os').environ.get('RP_BASE','.').rstrip('/')+'/new/'
D=['Set14','BSD100','Urban100','CBSD68']
df=pd.concat([pd.read_csv(B+'down_%s.csv'%d) for d in D],ignore_index=True)
MP={'oracle':'r_true','evt':'r_evt','selfcal':'r_selfcal','fixed':'r_fixed','autocorr':'r_autocorr','spectral':'r_spectral','svr':'r_svr','svr_tuned':'r_svr_tuned','svr_big':'r_svr_big'}
dd=df[['dataset','image','kernel_type','kernel_param','r_true','psnr_blurry','ssim_blurry']].copy(); alt=df[['dataset','image','kernel_type','kernel_param','r_true']].copy()
for m,o in MP.items():
    for a,b in [('psnr','psnr'),('ssim','ssim'),('kmse','kmse'),('rhat','rhat')]: dd[f'{a}_{o}']=df[f'{b}_{m}']
    alt[f'psnr_wiener_{o}']=df[f'psnr_w_{m}']; alt[f'ssim_wiener_{o}']=df[f'ssim_w_{m}']
    alt[f'psnr_rladapt_{o}']=df[f'psnr_a_{m}']; alt[f'ssim_rladapt_{o}']=df[f'ssim_a_{m}']; alt[f'niter_rladapt_{o}']=df[f'nad_{m}']
dd.to_csv(B+'results/downstream_deconv.csv',index=False); alt.to_csv(B+'results/downstream_deconv_altsolvers.csv',index=False)
NAME={'oracle':'Oracle (true $r$)','selfcal':'Probe-ratio EVT (ours)','evt':'Naive population-$\\Delta_0$ EVT','fixed':'Fixed default ($r{=}3$)',
 'autocorr':'Gradient autocorrelation','spectral':'Spectral-slope cutoff','svr':'HOG+SVR (25 img., fixed)','svr_tuned':'HOG+SVR (25 img., tuned)','svr_big':'HOG+SVR (65 img., 3 fam.)'}
ORDER=['oracle','selfcal','evt','fixed','autocorr','spectral','svr','svr_tuned','svr_big']; OTH=[m for m in ORDER if m!='selfcal']
df['img']=df.dataset+'/'+df.image; imgs=df.img.unique(); N=len(imgs)
rng=np.random.default_rng(7); picks=[rng.integers(0,N,N) for _ in range(4000)]
def pv(p):
    if p<1e-300:return '$<10^{-300}$'
    if p>=0.1: return '%.2f'%p
    e=int(math.floor(math.log10(p)));return '$%.1f\\times10^{%d}$'%(p/10**e,e)
def img_level(col): return df.groupby('img')[col].mean()
def compare(colfn,label):
    ours=img_level(colfn('selfcal')); out={}; ps=[]
    for m in OTH:
        d=(ours-img_level(colfn(m))).values; w=stats.wilcoxon(d) if np.any(d!=0) else None
        bs=np.percentile([d[p].mean() for p in picks],[2.5,97.5])
        out[m]=dict(diff=d.mean(),ci=list(bs),p=(w.pvalue if w else 1.0)); ps.append(out[m]['p'])
    o=np.argsort(ps);k=len(ps);run=0;adj=[0]*k
    for rank,i in enumerate(o): run=max(run,(k-rank)*ps[i]);adj[i]=min(run,1)
    for j,m in enumerate(OTH): out[m]['p_holm']=adj[j]
    return out
SOL={'RL':lambda m:f'psnr_{m}','Wiener':lambda m:f'psnr_w_{m}','RL-adaptive':lambda m:f'psnr_a_{m}'}
SSOL={'RL':lambda m:f'ssim_{m}','Wiener':lambda m:f'ssim_w_{m}','RL-adaptive':lambda m:f'ssim_a_{m}'}
res={'n_inst':len(df),'n_img':N,'mean_psnr':{},'mean_ssim':{},'cmp':{},'cmp_ssim':{}}
for s,fn in SOL.items():
    res['mean_psnr'][s]={m:float(df[fn(m)].mean()) for m in ORDER}; res['cmp'][s]=compare(fn,s)
    res['mean_ssim'][s]={m:float(df[SSOL[s](m)].mean()) for m in ORDER}; res['cmp_ssim'][s]=compare(SSOL[s],s)
res['blurry']=dict(psnr=float(df.psnr_blurry.mean()),ssim=float(df.ssim_blurry.mean()))
# oracle gain over blurry for each solver
res['oracle_gain']={s:float((df[fn('oracle')]-df.psnr_blurry).mean()) for s,fn in SOL.items()}
res['by_family_oracle_gain']={k:{s:float((g[fn('oracle')]-g.psnr_blurry).mean()) for s,fn in SOL.items()} for k,g in df.groupby('kernel_type')}
# table5: RL fixed 25
rows=['Blurry input (no deconvolution) & %.2f & %.3f & --- & --- \\\\'%(res['blurry']['psnr'],res['blurry']['ssim']),'\\midrule']
for m in ORDER:
    if m=='selfcal': rows.append('%s & %.2f & %.3f & --- & --- \\\\'%(NAME[m],res['mean_psnr']['RL'][m],res['mean_ssim']['RL'][m])); continue
    c=res['cmp']['RL'][m]; rows.append('%s & %.2f & %.3f & %+.2f [%+.2f, %+.2f] & %s \\\\'%(NAME[m],res['mean_psnr']['RL'][m],res['mean_ssim']['RL'][m],c['diff'],*c['ci'],pv(c['p_holm'])))
open(B+'tex/table5.tex','w').write('\\begin{tabular}{lcccc}\n\\toprule\nKernel-size source & PSNR (dB) & SSIM & Ours $-$ other, $\\Delta$PSNR [95\\% CI] & Holm $p$ \\\\\n\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\n\\end{tabular}\n')
# table9: Wiener and adaptive
rows=['%s & %.2f & %.3f & %.2f & %.3f \\\\'%(NAME[m],res['mean_psnr']['Wiener'][m],res['mean_ssim']['Wiener'][m],res['mean_psnr']['RL-adaptive'][m],res['mean_ssim']['RL-adaptive'][m]) for m in ORDER]
open(B+'tex/table9.tex','w').write('\\begin{tabular}{lcccc}\n\\toprule\nKernel-size source & Wiener PSNR & Wiener SSIM & RL-adaptive PSNR & RL-adaptive SSIM \\\\\n\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\n\\end{tabular}\n')
# table_down_ci: Wiener + adaptive (RL fixed is in table5)
rows=[]
for s in ['Wiener','RL-adaptive']:
    for m in OTH:
        c=res['cmp'][s][m]; rows.append('%s & %s & %+.2f [%+.2f, %+.2f] & %s \\\\'%(s,NAME[m],c['diff'],*c['ci'],pv(c['p_holm'])))
    rows.append('\\midrule')
open(B+'tex/table_down_ci.tex','w').write('\\begin{tabular}{llcc}\n\\toprule\nSolver & Ours minus & $\\Delta$PSNR [95\\% CI] (dB) & Holm $p$ \\\\\n\\midrule\n'+'\n'.join(rows[:-1])+'\n\\bottomrule\n\\end{tabular}\n')
# iteration sweep + cross-fitted tuned iteration count
P=[]
for d in D: P+=pickle.load(open(B+'down_%s.pkl'%d,'rb'))['paths']
keyimg=[]
for d in D:
    sub=pd.read_csv(B+'down_%s.csv'%d); keyimg+=list(d+'/'+sub.image)
assert len(P)==len(keyimg)
curves={m:np.array([p['paths'][m] for p in P]) for m in ORDER}     # (216,60)
res['sweep']={m:curves[m].mean(0).tolist() for m in ORDER}
res['best_iter_all']={m:int(curves[m].mean(0).argmax()+1) for m in ORDER}
ki=np.array(keyimg); ui=np.unique(ki); r2=np.random.default_rng(11); tuned=[]
for rep in range(50):
    perm=r2.permutation(ui); A=set(perm[:len(ui)//2]); fa=np.array([k in A for k in ki])
    row={}
    for m in ORDER:
        ia=curves[m][fa].mean(0).argmax(); ib=curves[m][~fa].mean(0).argmax()
        row[m]=0.5*(curves[m][~fa][:,ia].mean()+curves[m][fa][:,ib].mean())
    tuned.append(row)
res['tuned_crossfit']={m:float(np.mean([t[m] for t in tuned])) for m in ORDER}
res['tuned_crossfit_sd']={m:float(np.std([t[m] for t in tuned])) for m in ORDER}
# paired tuned-iteration comparison vs ours at the image level (use best iteration of all-data is optimistic -> use crossfit per image)
rows=['%s & %d & %.2f \\\\'%(NAME[m],res['best_iter_all'][m],res['tuned_crossfit'][m]) for m in ORDER]
open(B+'tex/table_tuned.tex','w').write('\\begin{tabular}{lcc}\n\\toprule\nKernel-size source & Best $T$ (all data) & PSNR at cross-fitted $T$ (dB) \\\\\n\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\n\\end{tabular}\n')
json.dump(res,open(B+'results/down_stats.json','w'),indent=1,default=float)
print(json.dumps({k:res[k] for k in ['blurry','oracle_gain','by_family_oracle_gain','best_iter_all','tuned_crossfit']},indent=1,default=float))
print(json.dumps(res['mean_psnr'],indent=1)); 
for s in SOL: print(s,{m:(round(res['cmp'][s][m]['diff'],2),[round(x,2) for x in res['cmp'][s][m]['ci']],round(res['cmp'][s][m]['p_holm'],4)) for m in OTH})
