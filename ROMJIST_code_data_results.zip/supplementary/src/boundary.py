from common import *
from scipy.signal import fftconvolve
C=json.load(open(BASE+'new/calib_params.json')); sc=core.SelfCalibratingEVT(tau=C['tau'],gamma=C['gamma'],w=5,probe_sigma=PROBE_SIGMA)
def blur_reflect(img,k):
    ph,pw=k.shape[0]//2,k.shape[1]//2; p=np.pad(img,((ph,ph),(pw,pw),(0,0)),mode='reflect')
    return np.clip(np.stack([fftconvolve(p[:,:,c],k,mode='valid') for c in range(3)],2),0,1)
fs=sorted(glob.glob(rk.DATASET_PATHS['Set14'])); rows=[]
cases=[('gaussian',2),('gaussian',5),('gaussian',8),('disk',3),('disk',8),('motion',6),('motion',18)]
for f in fs:
    img=rk.load_resized(f)
    for kt,p in cases:
        k,rt=rk.build_kernel(kt,p,np.random.default_rng(3)); a=sc.estimate_radius(core.apply_blur(img,k)); b=sc.estimate_radius(blur_reflect(img,k))
        rows.append(dict(img=os.path.basename(f),kt=kt,p=p,r=rt,zero=a,refl=b))
d=pd.DataFrame(rows) if 'pd' in globals() else None
import pandas as pd; d=pd.DataFrame(rows); d['ez']=(d.zero-d.r).abs(); d['er']=(d.refl-d.r).abs(); d['diff']=d.refl-d.zero
g=d.groupby('img')[['ez','er']].mean(); dd=(g.er-g.ez); bs=np.random.default_rng(1).integers(0,len(dd),(2000,len(dd))); bm=dd.values[bs].mean(1)
o=dict(n=len(d),mae_zero=float(d.ez.mean()),mae_reflect=float(d.er.mean()),mean_est_diff=float(d['diff'].mean()),mean_abs_est_diff=float(d['diff'].abs().mean()),max_abs_est_diff=float(d['diff'].abs().max()),paired_mae_diff=float(dd.mean()),ci=[float(np.percentile(bm,2.5)),float(np.percentile(bm,97.5))])
json.dump(o,open(BASE+'new/results/boundary.json','w'),indent=1); print(o)
