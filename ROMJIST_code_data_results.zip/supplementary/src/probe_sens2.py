from common import *
import pickle, json
from law import *
P=pickle.load(open(BASE+'new/pool.pkl','rb')); n25=P['n_set5']+P['n_calib']
C=json.load(open(BASE+'new/calib_params.json'))
imgs=[rk.load_resized(f) for f in P['files'][:n25]]
sig=[1,2,3,4,5,6,8,10]; ks=[core.gaussian_kernel(sigma=s) for s in sig]
bl=[[core.apply_blur(im,k[0]) for im in imgs] for k in ks]
d1=np.array([[core.dark_channel_depth(b,5)[0] for b in row] for row in bl])
out={}
for sp in [1,1.5,2,3,4,5,6,7,8,10]:
    pk,dr=core.gaussian_kernel(sigma=sp); e=[]
    for i,k in enumerate(ks):
        for j,b in enumerate(bl[i]):
            d2=core.dark_channel_depth(core.apply_blur(b,pk),5)[0]
            e.append(abs(invert(d2/d1[i,j],C['tau'],C['gamma'],dr)-k[1]))
    out[str(float(sp))]=float(np.mean(e)); print(sp,out[str(float(sp))],flush=True)
json.dump(out,open(BASE+'new/results/probe_sensitivity.json','w'))
