import glob,json,math,sys,numpy as np,pandas as pd
sys.path.insert(0,'../supp2/src'); import core
from scipy import stats
C=json.load(open('calib_params.json')); tau,gam=C['tau'],C['gamma']; RMAX=30.0
mp=pd.concat([pd.read_csv(f) for f in sorted(glob.glob('mp_*.csv'))],ignore_index=True)
full=pd.read_csv('results/kernel_size_ALL.csv')
key=['dataset','image','kernel_type','kernel_param','noise']
m=mp.merge(full[key+['r_selfcal','r_fixed','r_svr_tuned','r_svr_big','r_autocorr','r_spectral']],on=key)
assert len(m)==len(mp)==6432
m['img']=m.dataset+'/'+m.image
PS=[3.0,5.0,8.0]
def est(sig):
    d=core.gaussian_kernel(sigma=sig)[1]; c=(d/tau)**2
    rho=np.clip(m['d2_%g'%sig].values/np.maximum(m.d1.values,1e-8),1e-6,1-1e-6)
    q=rho**(-1/gam)-1; u0=c/q-1; u=np.maximum(u0,0)
    r=np.minimum(tau*np.sqrt(u),RMAX)
    a=1+u  # a=1+r^2/tau^2 at the estimate
    with np.errstate(divide='ignore',invalid='ignore'):
        S=tau*a*(a+c)/(2*gam*c*rho*np.sqrt(np.maximum(a-1,0)))
    inside=(u0>0)&(tau*np.sqrt(np.maximum(u0,0))<RMAX)
    S=np.where(inside,S,np.inf)
    return r,S,inside
R={};S={};I={}
for s in PS: R[s],S[s],I[s]=est(s)
print('probe5 reproduces r_selfcal: max abs diff',np.abs(R[5.0]-m.r_selfcal.values).max())
rt=m.r_true.values
def mae(x): return float(np.abs(x-rt).mean())
for s in PS: print('sigma_p',s,'MAE',round(mae(R[s]),3),'inside frac',round(I[s].mean(),3))
Rm=np.stack([R[s] for s in PS],1); Sm=np.stack([S[s] for s in PS],1); Im=np.stack([I[s] for s in PS],1)
med=np.median(Rm,1)
W=np.where(np.isfinite(Sm),1/np.maximum(Sm,1e-9)**2,0.0)
wsum=W.sum(1); wavg=np.where(wsum>0,(W*Rm).sum(1)/np.maximum(wsum,1e-30),np.nan)
Smin=Sm.min(1); allin=Im.all(1); anyin=Im.any(1)
print('median-of-3 MAE',mae(med))
ok=~np.isnan(wavg); print('precision-weighted MAE (reliable subset only)',float(np.abs(wavg[ok]-rt[ok]).mean()),'coverage',ok.mean())
# --- cross-fitted image-level evaluation ------------------------------------------------
imgs=m.img.unique(); idx={i:np.where(m.img.values==i)[0] for i in imgs}
rng=np.random.default_rng(20261024); NREP=100
def xfit(make):
    """make(train_idx)-> predictor(test_idx)->preds. returns per-image mean abs error averaged over reps held out"""
    acc={i:[] for i in imgs}; cover=[]
    for _ in range(NREP):
        p=rng.permutation(len(imgs)); A=[imgs[j] for j in p[:len(imgs)//2]]; B=[imgs[j] for j in p[len(imgs)//2:]]
        for tr,te in ((A,B),(B,A)):
            tri=np.concatenate([idx[i] for i in tr]); tei=np.concatenate([idx[i] for i in te])
            pred,cov=make(tri)(tei); e=np.abs(pred-rt[tei]); cover.append(cov)
            ii=m.img.values[tei]
            for i,v in pd.Series(e).groupby(ii): acc[i].append(float(v.mean()))
    return np.array([np.mean(acc[i]) for i in imgs]),float(np.mean(cover))
def const_make(tri):
    c=float(np.median(rt[tri])); return lambda tei:(np.full(len(tei),c),1.0)
base=R[5.0]
def fb_make(rhat,Sv,lo_grid=(0.0,),s_grid=(np.inf,100,60,40,30,20,15,10,7,5)):
    def mk(tri):
        c=float(np.median(rt[tri])); best=None
        for sg in s_grid:
            for lo in (0.0,0.5,1.0,1.5,2.0):
                use=(Sv[tri]<=sg)&(rhat[tri]>lo)&(rhat[tri]<RMAX)
                pr=np.where(use,rhat[tri],c); e=np.abs(pr-rt[tri]).mean()
                if best is None or e<best[0]: best=(e,sg,lo)
        _,sg,lo=best
        def f(tei):
            use=(Sv[tei]<=sg)&(rhat[tei]>lo)&(rhat[tei]<RMAX); return np.where(use,rhat[tei],c),float(use.mean())
        return f
    return mk
def shrink_make(rhat):
    def mk(tri):
        c=float(np.median(rt[tri])); ws=np.linspace(0,1,21); e=[np.abs(w*rhat[tri]+(1-w)*c-rt[tri]).mean() for w in ws]; w=ws[int(np.argmin(e))]
        return lambda tei:(w*rhat[tei]+(1-w)*c,1.0)
    return mk
Sbest=np.minimum.reduce([S[s] for s in PS])  # not used for estimate selection: see below
# multi-probe reliability: use the probe with the smallest sensitivity
j=np.argmin(Sm,1); r_minS=Rm[np.arange(len(m)),j]; S_minS=Sm[np.arange(len(m)),j]
res={}
def add(name,per_img,cov=1.0): res[name]=dict(per_img=per_img,mae=float(per_img.mean()),cov=cov)
v,cv=xfit(const_make); add('Validation-tuned constant$^\\dagger$',v,cv)
add('Fixed default r=3',pd.Series(np.abs(m.r_fixed.values-rt)).groupby(m.img.values).mean().reindex(imgs).values)
add('Ours: single probe',pd.Series(np.abs(base-rt)).groupby(m.img.values).mean().reindex(imgs).values)
add('Ours: median of 3 probes',pd.Series(np.abs(med-rt)).groupby(m.img.values).mean().reindex(imgs).values)
add('Ours: min-sensitivity probe',pd.Series(np.abs(r_minS-rt)).groupby(m.img.values).mean().reindex(imgs).values)
v,cv=xfit(fb_make(base,S[5.0])); add('Ours + reliability fallback$^\\dagger$',v,cv)
v,cv=xfit(fb_make(med,S_minS)); add('Median of 3 + reliability fallback$^\\dagger$',v,cv)
v,cv=xfit(fb_make(r_minS,S_minS)); add('Min-sensitivity probe + fallback$^\\dagger$',v,cv)
v,cv=xfit(shrink_make(base)); add('Ours shrunk toward constant$^\\dagger$',v,cv)
v,cv=xfit(shrink_make(med)); add('Median of 3 shrunk toward constant$^\\dagger$',v,cv)
add('HOG+SVR (25 img., tuned)',pd.Series(np.abs(m.r_svr_tuned.values-rt)).groupby(m.img.values).mean().reindex(imgs).values)
add('HOG+SVR (65 img., 3 fam.)',pd.Series(np.abs(m.r_svr_big.values-rt)).groupby(m.img.values).mean().reindex(imgs).values)
bs=np.random.default_rng(5); B=2000; P=bs.integers(0,len(imgs),(B,len(imgs)))
def ci(v): bm=v[P].mean(1); return [float(np.percentile(bm,2.5)),float(np.percentile(bm,97.5))]
out={}
ref=res['Ours: single probe']['per_img']; refc=res['Validation-tuned constant$^\\dagger$']['per_img']; reff=res['Fixed default r=3']['per_img']
ps=[]; names=list(res)
for n in names:
    v=res[n]['per_img']; d=v-ref; dc=v-refc; df=v-reff
    out[n]=dict(mae=res[n]['mae'],ci=ci(v),coverage=res[n]['cov'],vs_single=dict(d=float(d.mean()),ci=ci(d),p=float(stats.wilcoxon(v,ref).pvalue) if n!='Ours: single probe' else None),
                vs_tunedconst=dict(d=float(dc.mean()),ci=ci(dc)),vs_fixed=dict(d=float(df.mean()),ci=ci(df)))
# bins by true radius for key methods
bins=[0,2,4,8,15]; rb=pd.cut(rt,bins,right=False)
ex={}
def full_pred(name):
    return {'Ours: single probe':base,'Ours: median of 3 probes':med,'Validation-tuned constant':np.full(len(m),np.median(rt)),'Fixed default r=3':m.r_fixed.values}[name]
for n in ['Ours: single probe','Ours: median of 3 probes','Validation-tuned constant','Fixed default r=3']:
    ex[n]=pd.Series(np.abs(full_pred(n)-rt)).groupby(rb).mean().tolist()
out['_bins_mae']=ex; out['_median_constant']=float(np.median(rt))
# risk-coverage curve using sensitivity of single probe (all data)
sv=S[5.0]; order=np.argsort(sv); e=np.abs(base-rt)
cov=np.linspace(0.05,1.0,40); rc=[float(e[order[:int(round(c*len(e)))]].mean()) for c in cov]
out['_risk_coverage']=dict(cov=cov.tolist(),risk=rc)
fin=np.isfinite(sv)
out['_sens_corr']=dict(spearman_S_abs_err=float(stats.spearmanr(np.where(fin,sv,1e6),e)[0]),frac_clamped_or_outside=float(1-I[5.0].mean()),mae_inside=float(e[I[5.0]].mean()),mae_outside=float(e[~I[5.0]].mean()))
out['_probe_mae']={str(s):mae(R[s]) for s in PS}
json.dump(out,open('results/mp_stats.json','w'),indent=1)
def pv(p):
    if p is None: return '--'
    e=int(math.floor(math.log10(p)));return '$%.1f\\times10^{%d}$'%(p/10**e,e)
rows=[]
for n in names:
    o=out[n]; vs='--' if n=='Ours: single probe' else '%+.2f [%+.2f, %+.2f]'%(o['vs_single']['d'],*o['vs_single']['ci'])
    vc='%+.2f [%+.2f, %+.2f]'%(o['vs_tunedconst']['d'],*o['vs_tunedconst']['ci']) if n!='Validation-tuned constant$^\\dagger$' else '--'
    rows.append('%s & %.2f [%.2f, %.2f] & %.0f\\%% & %s & %s \\\\'%(n,o['mae'],*o['ci'],100*o['coverage'],vs,vc))
open('tex/table_mp.tex','w').write('\\begin{tabular}{lcccc}\n\\toprule\nEstimator & MAE (px) [95\\% CI] & Cov. & vs.\\ single probe [95\\% CI] & vs.\\ tuned const. [95\\% CI] \\\\\n\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\n\\end{tabular}\n')
print(open('tex/table_mp.tex').read()); print(json.dumps({k:out[k] for k in out if k.startswith('_')},indent=0)[:1500])
# ---- labelled-data learning curve for the two-parameter shrinkage (c, w) and for the constant alone ----
lc={}; rng2=np.random.default_rng(77); ws=np.linspace(0,1,21)
for n in (1,2,3,5,10,25,60):
    ec=[];es=[];wl=[]
    for _ in range(100):
        p=rng2.permutation(len(imgs)); tr=np.concatenate([idx[imgs[j]] for j in p[:n]]); te=np.concatenate([idx[imgs[j]] for j in p[n:]])
        c=float(np.median(rt[tr])); er=[np.abs(w*base[tr]+(1-w)*c-rt[tr]).mean() for w in ws]; w=ws[int(np.argmin(er))]
        ec.append(np.abs(c-rt[te]).mean()); es.append(np.abs(w*base[te]+(1-w)*c-rt[te]).mean()); wl.append(w)
    lc[n]=dict(const=float(np.mean(ec)),shrink=float(np.mean(es)),shrink_sd=float(np.std(es)),w=float(np.mean(wl)))
    print('n labelled images',n,lc[n])
out['_learning_curve']=lc; json.dump(out,open('results/mp_stats.json','w'),indent=1)
# ---- prior-shift test: tune (c,w) on one kernel family, test on the others; and on small radii -> large radii ----
kt=m.kernel_type.values; sh={}
def tune(tr):
    c=float(np.median(rt[tr])); er=[np.abs(w*base[tr]+(1-w)*c-rt[tr]).mean() for w in ws]; return c,ws[int(np.argmin(er))]
for fam in ('gaussian','disk','motion'):
    tr=np.where(kt==fam)[0]; c,w=tune(tr)
    for tf in ('gaussian','disk','motion'):
        te=np.where(kt==tf)[0]
        sh[f'{fam}->{tf}']=dict(c=c,w=w,const=float(np.abs(c-rt[te]).mean()),shrink=float(np.abs(w*base[te]+(1-w)*c-rt[te]).mean()),ours=float(np.abs(base[te]-rt[te]).mean()),fixed3=float(np.abs(3-rt[te]).mean()))
tr=np.where(rt<5)[0]; te=np.where(rt>=5)[0]; c,w=tune(tr)
sh['r<5->r>=5']=dict(c=c,w=w,const=float(np.abs(c-rt[te]).mean()),shrink=float(np.abs(w*base[te]+(1-w)*c-rt[te]).mean()),ours=float(np.abs(base[te]-rt[te]).mean()),fixed3=float(np.abs(3-rt[te]).mean()))
out['_prior_shift']=sh; json.dump(out,open('results/mp_stats.json','w'),indent=1)
for k,v in sh.items(): print(k,{a:round(b,2) for a,b in v.items()})
