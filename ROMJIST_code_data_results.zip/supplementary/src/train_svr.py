from common import *
import pickle
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GroupKFold, GridSearchCV
from sklearn.pipeline import make_pipeline
P=pickle.load(open(BASE+'new/pool.pkl','rb'))
n25=P['n_set5']+P['n_calib']
def data(fams,imgmask):
    X=[];y=[];g=[]
    for f in fams:
        d=P['fam'][f]; m=np.isin(d['g'],imgmask); X.append(d['X'][m]); y.append(d['y'][m]); g.append(d['g'][m])
    X.append(P['X0'][imgmask]); y.append(np.zeros(len(imgmask))); g.append(np.array(imgmask))
    return np.vstack(X),np.concatenate(y),np.concatenate(g)
out={}
Xa,ya,ga=data(['gaussian'],list(range(n25)))
base=make_pipeline(StandardScaler(),SVR(kernel='rbf',C=10.0,epsilon=0.1))
out['svr_orig']=base.fit(Xa,ya)
grid={'svr__C':[1,10,100,1000],'svr__epsilon':[0.05,0.2,0.5],'svr__gamma':['scale',1e-5,1e-4]}
gs=GridSearchCV(make_pipeline(StandardScaler(),SVR(kernel='rbf')),grid,cv=GroupKFold(5),scoring='neg_mean_absolute_error',n_jobs=4)
gs.fit(Xa,ya,groups=ga); out['svr_tuned']=gs.best_estimator_; print('tuned25',gs.best_params_,-gs.best_score_,flush=True)
n=len(P['files']); Xb,yb,gb=data(['gaussian','disk','motion'],list(range(n)))
gs2=GridSearchCV(make_pipeline(StandardScaler(),SVR(kernel='rbf')),{'svr__C':[10,100,1000],'svr__epsilon':[0.2],'svr__gamma':['scale',1e-5]},cv=GroupKFold(5),scoring='neg_mean_absolute_error',n_jobs=4)
gs2.fit(Xb,yb,groups=gb); out['svr_big']=gs2.best_estimator_; print('big',gs2.best_params_,-gs2.best_score_,len(yb),flush=True)
out['info']=dict(tuned25=dict(gs.best_params_,cv_mae=-gs.best_score_,n=len(ya)),big=dict(gs2.best_params_,cv_mae=-gs2.best_score_,n=len(yb)))
pickle.dump(out,open(BASE+'new/svr.pkl','wb'))
