import glob,json,numpy as np,pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy import stats
plt.rcParams.update({'font.family':'serif','font.size':8,'axes.grid':True,'grid.linewidth':0.3,'figure.dpi':200})
d=pd.concat([pd.read_csv(f) for f in sorted(glob.glob('down_*.csv'))],ignore_index=True); d['img']=d.dataset+'/'+d.image
out={}
fam={'gaussian':'Gaussian','disk':'Disk','motion':'Line'}; mk={'gaussian':'o','disk':'s','motion':'^'}
f,ax=plt.subplots(1,2,figsize=(7.0,2.8))
for m,a,t in (('selfcal',ax[0],'(a) Ours'),('svr_tuned',ax[1],'(b) HOG+SVR (25 img., tuned)')):
    e=np.abs(d['rhat_'+m]-d.r_true); g=d['psnr_'+m]-d.psnr_blurry
    for k in fam: s=d.kernel_type==k; a.scatter(e[s],g[s],s=9,marker=mk[k],facecolors='none',edgecolors='k',linewidths=0.5,label=fam[k])
    a.axhline(0,color='k',lw=0.6); a.set_xlabel('$|\\hat r-r|$ (px)'); a.set_ylabel('PSNR gain over blurry input (dB)'); a.set_title(t,loc='left',fontsize=8.5)
    rho=stats.spearmanr(e,g); out[m]=dict(spearman=float(rho[0]),p=float(rho[1]))
    out[m]['frac_gain_positive']=float((g>0).mean()); out[m]['median_gain']=float(g.median())
    b=pd.cut(e,[0,1,2,4,8,100],right=False); out[m]['gain_by_err_bin']={str(k):float(v) for k,v in g.groupby(b,observed=True).mean().items()}
    out[m]['n_by_err_bin']={str(k):int(v) for k,v in g.groupby(b,observed=True).size().items()}
ax[0].legend(fontsize=7)
f.tight_layout(); f.savefig('figs/T_psnr_vs_err.pdf'); 
# per-image gains
for m in ('oracle','selfcal','fixed','svr_tuned'):
    pg=(d['psnr_'+m]-d.psnr_blurry).groupby(d.img).mean(); out['perimg_'+m]=dict(mean=float(pg.mean()),frac_images_positive=float((pg>0).mean()),min=float(pg.min()),max=float(pg.max()))
# by family, ours
out['by_family_gain_ours']={k:float((g_:=d.loc[d.kernel_type==k,'psnr_selfcal']-d.loc[d.kernel_type==k,'psnr_blurry']).mean()) for k in fam}
out['by_family_gain_oracle']={k:float((d.loc[d.kernel_type==k,'psnr_oracle']-d.loc[d.kernel_type==k,'psnr_blurry']).mean()) for k in fam}
# gain when error small
e=np.abs(d.rhat_selfcal-d.r_true); out['ours_err_lt1']=dict(n=int((e<1).sum()),gain=float((d.psnr_selfcal-d.psnr_blurry)[e<1].mean()))
# per-image gain histogram (ours, oracle)
f,ax=plt.subplots(figsize=(3.45,2.6))
pgo=(d.psnr_oracle-d.psnr_blurry).groupby(d.img).mean().sort_values(); idx=pgo.index
pgs=(d.psnr_selfcal-d.psnr_blurry).groupby(d.img).mean().reindex(idx)
x=np.arange(len(idx)); ax.bar(x-0.2,pgo.values,0.4,color='white',edgecolor='k',hatch='//',label='Oracle'); ax.bar(x+0.2,pgs.values,0.4,color='0.4',edgecolor='k',label='Ours')
ax.axhline(0,color='k',lw=0.6); ax.set_xlabel('Image (sorted by oracle gain)'); ax.set_ylabel('Mean PSNR gain (dB)'); ax.set_xticks([]); ax.legend(fontsize=7); f.tight_layout(); f.savefig('figs/U_perimage.pdf')
json.dump(out,open('results/down_extra.json','w'),indent=1); print(json.dumps(out,indent=1))
