import json,numpy as np,pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy import stats
plt.rcParams.update({'font.family':'Liberation Sans','mathtext.fontset':'dejavusans','font.size':7.5,'axes.grid':True,'grid.linewidth':0.3,'figure.dpi':200})
a=pd.read_csv('kern_matched.csv'); out={}
a['err']=a.r_hat-a.r_true
g=a.groupby(['r_nom','kernel']).agg(rho=('rho','mean'),rho_sd=('rho','std'),rhat=('r_hat','mean'),rhat_sd=('r_hat','std'),rtrue=('r_true','mean')).reset_index()
out['matched']=g.round(4).to_dict('records')
# spread across kernels at the same r (between-kernel sd of mean rho) vs within-kernel sd across images
sp=g.groupby('r_nom').agg(between_rho=('rho','std'),within_rho=('rho_sd','mean'),between_rhat=('rhat','std'),within_rhat=('rhat_sd','mean')).reset_index(); out['spread']=sp.round(4).to_dict('records')
# Kruskal test of rho across kernels per radius (image-level, 30 imgs per kernel)
out['kruskal']={}
for r,sub in a.groupby('r_nom'):
    out['kruskal'][str(r)]=float(stats.kruskal(*[x.rho.values for _,x in sub.groupby('kernel')]).pvalue)
# aggregate by kernel over radii: mean signed error and MAE
k=a.groupby('kernel').agg(mae=('err',lambda x:float(np.abs(x).mean())),bias=('err','mean')).round(3); out['by_kernel']=k.to_dict('index')
fam={'Gaussian':'o','Disk':'s','Line0':'^','Line45':'^','Line90':'^','Ani2_0':'v','Ani2_45':'v','Ani2_90':'v','Ani4_0':'D','Ani4_90':'D'}
fig,ax=plt.subplots(1,2,figsize=(5.17,3.54))
for n,sub in g.groupby('kernel'):
    ax[0].plot(sub.r_nom,sub.rho,marker=fam[n],ms=3.5,lw=0.7,mfc='none',color='k',alpha=0.9,label=n)
    ax[1].plot(sub.r_nom,sub.rhat,marker=fam[n],ms=3.5,lw=0.7,mfc='none',color='k',alpha=0.9)
ax[1].plot([1,9],[1,9],'k:',lw=0.8); ax[0].set_xlabel('Matched effective radius (px)'); ax[0].set_ylabel('Mean probe ratio $\\rho$'); ax[1].set_xlabel('Matched effective radius (px)'); ax[1].set_ylabel('Mean estimate $\\hat r$ (px)')
ax[0].set_title('(a)',loc='left'); ax[1].set_title('(b)',loc='left'); h,l=ax[0].get_legend_handles_labels(); fig.tight_layout(rect=(0,0.1,1,1)); fig.legend(h,l,fontsize=6,ncol=4,loc='lower center'); fig.savefig('figs_sn/V_matched.pdf')
# robustness table
b=pd.read_csv('kern_robust.csv'); R=b[b.exp=='robust'].copy(); R['ae']=(R.r_hat-R.r_true).abs(); R['e']=R.r_hat-R.r_true
t=R.groupby('cond').agg(mae=('ae','mean'),bias=('e','mean')).reindex(['clean','Poisson-Gaussian P=1000, s=0.005','Poisson-Gaussian P=100, s=0.01','JPEG q=75','JPEG q=50','JPEG q=30'])
cl=R[R.cond=='clean'].set_index(['kernel','r_true','image']).ae
dif={}
for c in t.index[1:]:
    x=R[R.cond==c].set_index(['kernel','r_true','image']).ae; d=(x-cl).groupby(level='image').mean(); bs=np.random.default_rng(3).integers(0,len(d),(2000,len(d))); bm=d.values[bs].mean(1)
    dif[c]=[float(d.mean()),float(np.percentile(bm,2.5)),float(np.percentile(bm,97.5))]
out['robust']={c:dict(mae=float(t.loc[c,'mae']),bias=float(t.loc[c,'bias']),d_vs_clean=dif.get(c)) for c in t.index}
V=b[b.exp=='varying'].copy(); V['r_ref']=np.sqrt((V.r_true**2+V.r_true2**2)/2)
vv=V.groupby('r_true').agg(left=('r_true','first'),right=('r_true2','first'),rms=('r_ref','first'),est=('r_hat','mean'),sd=('r_hat','std')).reset_index(drop=True); out['varying']=vv.round(3).to_dict('records')
json.dump(out,open('results/kern_stats.json','w'),indent=1)
def f(x): return '%.2f'%x
rows=[]
for c in t.index:
    d='--' if c=='clean' else '%+.2f [%+.2f, %+.2f]'%tuple(dif[c])
    rows.append('%s & %.2f & %+.2f & %s \\\\'%(c.replace('=',' = ').replace('s = ','$\\sigma$ = '),t.loc[c,'mae'],t.loc[c,'bias'],d))
open('tex/table_robust.tex','w').write('\\begin{tabular}{lccc}\n\\toprule\nCondition & MAE (px) & Bias (px) & $\\Delta$MAE vs.\\ clean [95\\% CI] \\\\\n\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\n\\end{tabular}\n')
rows=[]
for kn,sub in g.groupby('kernel'):
    rows.append(kn.replace('_','/')+' & '+' & '.join('%.3f / %.2f'%(sub[sub.r_nom==r].rho.iloc[0],sub[sub.r_nom==r].rhat.iloc[0]) for r in (2,4,6,8))+' \\\\')
open('tex/table_matched.tex','w').write('\\begin{tabular}{lcccc}\n\\toprule\nKernel & $r{=}2$ & $r{=}4$ & $r{=}6$ & $r{=}8$ \\\\\n\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\n\\end{tabular}\n')
print(open('tex/table_matched.tex').read()); print(open('tex/table_robust.tex').read()); print(json.dumps({k:out[k] for k in ('spread','kruskal','by_kernel','varying')},indent=0))
