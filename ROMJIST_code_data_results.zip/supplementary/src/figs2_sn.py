import json, numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon, Rectangle
BASE='/tmp/claude-0/-home-claude/20c06ce3-e3d6-50c1-8e99-9a4589b67841/scratchpad/'
R=BASE+'new/results/'; O=BASE+'new/figs_sn/'
plt.rcParams.update({'font.family':'Liberation Sans','mathtext.fontset':'dejavusans',
 'font.size':8,'axes.labelsize':8,'axes.titlesize':8,'legend.fontsize':6.5,'xtick.labelsize':7.5,'ytick.labelsize':7.5,
 'axes.linewidth':0.6,'xtick.direction':'in','ytick.direction':'in','xtick.top':True,'ytick.right':True,
 'grid.linestyle':':','grid.linewidth':0.4,'grid.color':'0.6','lines.linewidth':1.0,'lines.markersize':4,
 'legend.frameon':True,'legend.edgecolor':'0.0','legend.fancybox':False,'legend.framealpha':1,
 'savefig.dpi':600,'pdf.fonttype':42,'figure.dpi':150})
full=pd.read_csv(R+'kernel_size_ALL.csv'); dd=pd.read_csv(R+'downstream_deconv.csv'); alt=pd.read_csv(R+'downstream_deconv_altsolvers.csv')
st=json.load(open(BASE+'new/results/stats.json'))
M=['r_selfcal','r_evt','r_fixed','r_autocorr','r_spectral','r_svr','r_svr_tuned','r_svr_big']
LAB={'r_selfcal':'Probe-ratio EVT (ours)','r_evt':'Naive EVT','r_fixed':'Fixed default','r_autocorr':'Grad. autocorr.','r_spectral':'Spectral slope','r_svr':'HOG+SVR (sup.)','r_svr_tuned':'SVR tuned','r_svr_big':'SVR 65 img.'}
GR={'r_selfcal':'0.25','r_evt':'0.85','r_fixed':'0.7','r_autocorr':'1.0','r_spectral':'0.55','r_svr':'1.0','r_svr_tuned':'0.4','r_svr_big':'0.15'}
HT={'r_selfcal':'','r_evt':'////','r_fixed':'....','r_autocorr':'\\\\\\\\','r_spectral':'xxxx','r_svr':'++++','r_svr_tuned':'oo','r_svr_big':'**'}
MK={'r_selfcal':'o','r_evt':'s','r_fixed':'^','r_autocorr':'v','r_spectral':'D','r_svr':'x','r_svr_tuned':'P','r_svr_big':'*'}
LS={'r_selfcal':'-','r_evt':'--','r_fixed':':','r_autocorr':'-.','r_spectral':(0,(5,1,1,1)),'r_svr':(0,(3,1,1,1,1,1)),'r_svr_tuned':(0,(1,1)),'r_svr_big':(0,(6,2))}
def save(f,n): f.savefig(O+n+'.pdf',bbox_inches='tight'); plt.close(f)
# ---------- flowchart helpers ----------
def box(ax,x,y,w,h,t,kind='proc',fs=7.5,fill='white'):
    if kind=='term': p=FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=0,rounding_size=%f'%(h/2),fc='0.88',ec='k',lw=0.8)
    elif kind=='io': d=h*0.35; p=Polygon([(x-w/2+d,y+h/2),(x+w/2+d,y+h/2),(x+w/2-d,y-h/2),(x-w/2-d,y-h/2)],fc='white',ec='k',lw=0.8)
    elif kind=='dec': p=Polygon([(x,y+h/2),(x+w/2,y),(x,y-h/2),(x-w/2,y)],fc='0.95',ec='k',lw=0.8)
    elif kind=='sub': p=Rectangle((x-w/2,y-h/2),w,h,fc='0.93',ec='k',lw=0.8)
    else: p=Rectangle((x-w/2,y-h/2),w,h,fc=fill,ec='k',lw=0.8)
    ax.add_patch(p); ax.text(x,y,t,ha='center',va='center',fontsize=fs,linespacing=1.15)
    if kind=='sub': ax.add_patch(Rectangle((x-w/2+0.07*w,y-h/2),0,h,fc='none',ec='k',lw=0.6)); ax.add_patch(Rectangle((x+w/2-0.07*w,y-h/2),0,h,fc='none',ec='k',lw=0.6))
def arr(ax,p,q,t=None,tpos=(0,0),ls='-',route=None):
    pts=[p]+(route or [])+[q]
    for a,b in zip(pts[:-2],pts[1:-1]): ax.plot([a[0],b[0]],[a[1],b[1]],'k',lw=0.8,ls=ls)
    ax.annotate('',xy=pts[-1],xytext=pts[-2],arrowprops=dict(arrowstyle='-|>',color='k',lw=0.8,shrinkA=0,shrinkB=0,mutation_scale=7,ls=ls))
    if t: mx=(p[0]+q[0])/2+tpos[0]; my=(p[1]+q[1])/2+tpos[1]; ax.text(mx,my,t,fontsize=7,ha='center',va='center',bbox=dict(fc='white',ec='none',pad=0.5))
# ---------- Fig A: pipeline ----------
f,ax=plt.subplots(figsize=(5.17,4.88)); ax.set_xlim(0,14); ax.set_ylim(0,7.6); ax.axis('off')
box(ax,1.5,5.3,2.4,1.0,'Blurry image $B$\n(RGB, $\\leq$256 px)','io')
box(ax,5.2,6.6,2.9,0.95,'Median pre-filter ($3{\\times}3$)\nand patch extraction\n($48{\\times}48$, stride 24)','proc')
box(ax,9.2,6.6,2.5,0.95,'Dark-channel depth\n$\\Delta_1=\\Delta_w(B)$','sub')
box(ax,5.2,4.0,2.9,0.95,'Gaussian probe blur\n$\\sigma_p=5$ px, radius $\\delta$','proc')
box(ax,9.2,4.0,2.5,0.95,'Dark-channel depth\n$\\Delta_2=\\Delta_w(B*k_\\sigma)$','sub')
ax.plot([2.9,3.2,3.2],[5.3,5.3,6.6],'k',lw=0.8); ax.annotate('',xy=(3.72,6.6),xytext=(3.2,6.6),arrowprops=dict(arrowstyle='-|>',color='k',lw=0.8,mutation_scale=7,shrinkA=0,shrinkB=0))
ax.plot([2.9,3.2,3.2],[5.3,5.3,4.0],'k',lw=0.8); ax.annotate('',xy=(3.72,4.0),xytext=(3.2,4.0),arrowprops=dict(arrowstyle='-|>',color='k',lw=0.8,mutation_scale=7,shrinkA=0,shrinkB=0))
arr(ax,(6.7,6.6),(7.9,6.6)); arr(ax,(6.7,4.0),(7.9,4.0))
ax.annotate('',xy=(10.9,5.3),xytext=(10.99,5.3),arrowprops=dict(arrowstyle='-|>',color='k',lw=0.8,mutation_scale=7,shrinkA=0,shrinkB=0)) if False else None
ax.annotate('',xy=(11.5,5.3),xytext=(11.4,5.3),arrowprops=dict(arrowstyle='-|>',color='k',lw=0.8,mutation_scale=7,shrinkA=0,shrinkB=0))
box(ax,12.75,5.3,2.5,1.15,'Ratio $\\rho=\\Delta_2/\\Delta_1$\n($\\Delta_0$ cancels)','proc')
ax.plot([10.45,11.4,11.4],[6.6,6.6,5.3],'k',lw=0.8); ax.plot([10.45,11.4,11.4],[4.0,4.0,5.3],'k',lw=0.8); arr(ax,(11.4,5.3),(10.9+0.6,5.3)) if False else None
box(ax,12.75,3.0,2.5,1.15,'Closed-form inversion\n$\\hat r=\\tau\\sqrt{\\max(u,0)}$','proc')
arr(ax,(12.75,4.72),(12.75,3.58))
box(ax,12.75,1.1,2.5,0.95,'Clip $\\hat r$ to $[0,30]$ px','proc')
arr(ax,(12.75,2.42),(12.75,1.58))
box(ax,8.6,1.1,3.0,0.95,'Assumed kernel $k_{\\hat r}$\n(family known)','proc')
box(ax,4.9,1.1,3.0,0.95,'Non-blind deconvolution\n(Wiener / Richardson--Lucy)','proc')
box(ax,1.5,1.1,2.4,0.95,'Restored image $\\hat I$','io')
arr(ax,(11.5,1.1),(10.1,1.1)); arr(ax,(7.1,1.1),(6.4,1.1)); arr(ax,(3.4,1.1),(2.7,1.1))
ax.text(0.1,7.4,'(a) measure',fontsize=7.5,style='italic'); ax.text(0.1,3.2,'(b) estimate and restore',fontsize=7.5,style='italic')
save(f,'A_pipeline')
# ---------- Fig B: algorithm flowchart (landscape) ----------
def ah(ax,p,q): ax.annotate('',xy=q,xytext=p,arrowprops=dict(arrowstyle='-|>',color='k',lw=0.8,mutation_scale=7,shrinkA=0,shrinkB=0))
f,ax=plt.subplots(figsize=(5.17,4.15)); ax.set_xlim(0,14); ax.set_ylim(0,6.8); ax.axis('off')
y1=5.8; y2=3.3; y3=0.9
box(ax,1.0,y1,1.8,0.8,'Start:\nimage $B$','term',fs=7)
box(ax,3.75,y1,2.9,1.0,'Load $(\\tau,\\gamma)$, $\\sigma_p$;  $\\delta=r(k_{\\sigma_p})$,\n$c=\\delta^2/\\tau^2$','io',fs=6.8)
box(ax,6.9,y1,2.3,0.8,'$\\Delta_1\\leftarrow\\Delta_w(B)$','sub',fs=7.5)
box(ax,9.7,y1,2.7,0.8,'$\\Delta_2\\leftarrow\\Delta_w(B*k_{\\sigma_p})$','sub',fs=7.2)
box(ax,12.6,y1,2.4,0.8,'$\\rho\\leftarrow\\Delta_2/\\Delta_1$','proc',fs=7.5)
ah(ax,(1.9,y1),(2.3,y1)); ah(ax,(5.2,y1),(5.75,y1)); ah(ax,(8.05,y1),(8.35,y1)); ah(ax,(11.05,y1),(11.4,y1))
box(ax,12.6,y2,2.4,1.0,'clip $\\rho$ to\n$[10^{-6},1-10^{-6}]$','proc',fs=6.8); ah(ax,(12.6,y1-0.4),(12.6,y2+0.5))
box(ax,10.0,y2,2.2,0.8,'$q\\leftarrow\\rho^{-1/\\gamma}-1$','proc',fs=7.2); ah(ax,(11.4,y2),(11.1,y2))
box(ax,7.3,y2,2.2,1.2,'$q\\leq10^{-8}$?','dec',fs=7.5); ah(ax,(8.9,y2),(8.4,y2))
box(ax,4.5,y2,2.4,0.8,'$u\\leftarrow\\max(c/q-1,\\,0)$','proc',fs=7.0); ah(ax,(6.7,y2),(5.7,y2)); ax.text(6.2,y2+0.25,'no',fontsize=7,ha='center')
box(ax,1.7,y2,2.6,1.0,'$\\hat r\\leftarrow\\min(\\tau\\sqrt{u},R_{\\max})$;\nreturn','term',fs=6.8); ah(ax,(3.3,y2),(3.0,y2))
box(ax,7.3,y3,2.2,0.7,'$\\hat r\\leftarrow0$;  return','term',fs=7.2); ah(ax,(7.3,y2-0.6),(7.3,y3+0.35)); ax.text(7.55,2.1,'yes',fontsize=7)
save(f,'B_algorithm')
# ---------- Fig C: experimental protocol ----------
f,ax=plt.subplots(figsize=(5.17,4.76)); ax.set_xlim(0,14); ax.set_ylim(0,7.6); ax.axis('off')
box(ax,2.3,6.7,3.6,0.9,'Reference corpus (25 images)\nSet5 + 20 held-out BSD100','io',fs=7)
box(ax,6.7,6.7,3.4,0.9,'Fit $(\\tau,\\gamma)$, select $\\sigma_p$,\ntrain HOG+SVR (same 25)','proc',fs=7)
arr(ax,(4.5,6.7),(5.0,6.7))
box(ax,11.6,6.7,4.2,0.9,'Evaluation images (4 datasets)\nSet14, BSD100, Urban100, CBSD68','io',fs=7)
box(ax,11.6,5.2,4.2,0.9,'Blur: 3 kernel families $\\times$ 8 scales\n$\\times$ 2 noise levels = 6432 instances','proc',fs=7)
arr(ax,(11.6,6.25),(11.6,5.65))
box(ax,8.7,3.7,5.6,0.9,'Six estimators: ours, naive EVT, fixed default,\ngradient autocorr., spectral slope, HOG+SVR','sub',fs=7)
ax.plot([6.7,6.7],[6.25,4.15+0.3],'k',lw=0.8); ax.annotate('',xy=(6.7,4.15),xytext=(6.7,4.5),arrowprops=dict(arrowstyle='-|>',color='k',lw=0.8,mutation_scale=7,shrinkA=0,shrinkB=0))
arr(ax,(11.6,4.75),(11.6,4.15))
ax.plot([8.7,8.7],[3.25,2.75],'k',lw=0.8); ax.plot([2.9,12.0],[2.75,2.75],'k',lw=0.8)
box(ax,2.9,1.7,4.6,1.1,'Upstream: MAE, RMSE, Pearson $r$,\nclustered bootstrap CIs,\nWilcoxon with Holm correction','proc',fs=7)
box(ax,7.6,1.7,4.0,1.1,'Downstream (216 instances):\nRichardson--Lucy, Wiener,\nadaptive RL; PSNR, SSIM','proc',fs=7)
box(ax,12.0,1.7,3.5,1.1,'Cross-domain: DRIVE\n(40 images, 20/20 split),\nrecalibrate $(\\tau,\\gamma)$','proc',fs=7)
for x in (2.9,7.6,12.0): arr(ax,(x,2.75),(x,2.25))
ax.text(0.15,7.35,'(a) calibration',fontsize=7.5,style='italic'); ax.text(9.3,7.35,'(b) evaluation',fontsize=7.5,style='italic')
save(f,'C_protocol')
# ---------- Fig D: calibration fit + residuals ----------
cc=json.load(open(R+'calib_curve.json')); r=np.array(cc['r']); d=np.array(cc['delta'])
mod=lambda x: cc['delta0']*(1+(x/cc['tau'])**2)**(-cc['gamma'])
f,(a1,a2)=plt.subplots(1,2,figsize=(5.17,3.29),gridspec_kw={'width_ratios':[1.5,1]})
xs=np.linspace(0,12,200)
a1.plot(xs,mod(xs),'k-',label='Fitted law, Eq. (3)'); a1.plot(r,d,'ko',mfc='white',label='Measured $\\Delta(r)$')
a1.set_xlabel('Blur effective radius $r$ (px)'); a1.set_ylabel('Dark-channel depth $\\Delta$'); a1.grid(True); a1.legend(loc='upper right'); a1.set_title('(a)',loc='left')
a2.axhline(0,color='k',lw=0.6); a2.plot(r,(d-mod(r))*1e3,'k^',mfc='0.6'); a2.set_xlabel('$r$ (px)'); a2.set_ylabel('Residual ($\\times10^{-3}$)'); a2.grid(True); a2.set_title('(b)',loc='left')
f.tight_layout(); save(f,'D_calibration')
# ---------- Fig E: scatter ----------
f,axs=plt.subplots(1,4,figsize=(5.17,2.81),sharex=True,sharey=True)
for ax,ds in zip(axs,['Set14','BSD100','Urban100','CBSD68']):
    s_=full[(full.dataset==ds)&(full.noise==0)]
    for kt,mk,fc in [('gaussian','o','none'),('disk','s','0.5'),('motion','^','k')]:
        q=s_[s_.kernel_type==kt]; ax.scatter(q.r_true,q.r_selfcal,s=5,marker=mk,facecolors=fc,edgecolors='k',linewidths=0.35,label=kt.capitalize(),rasterized=True)
    ax.plot([0,32],[0,32],'k--',lw=0.7); ax.set_xlim(0,32); ax.set_ylim(0,32); ax.grid(True); ax.set_title(ds,fontsize=8.5); ax.set_xlabel('True $r$ (px)',fontsize=8)
axs[0].set_ylabel('Estimate $\\hat r$ (px)'); axs[0].legend(loc='upper left',fontsize=6.5,markerscale=1.3); f.tight_layout(); save(f,'E_scatter')
# ---------- Fig F: forest plot MAE with CI ----------
f,(a1,a2)=plt.subplots(1,2,figsize=(5.17,3.42),gridspec_kw={'width_ratios':[1.15,1]})
ord_=['r_selfcal','r_svr','r_svr_tuned','r_svr_big','r_fixed','r_spectral','r_autocorr','r_evt']
for i,m in enumerate(ord_):
    v=st['mae'][m]; a1.errorbar(v['mae'],i,xerr=[[v['mae']-v['mae_ci'][0]],[v['mae_ci'][1]-v['mae']]],fmt=MK[m] if MK[m]!='x' else 'x',color='k',mfc='white' if m!='r_selfcal' else 'k',capsize=3,ms=5)
a1.set_yticks(range(len(ord_))); a1.set_yticklabels([LAB[m] for m in ord_]); a1.invert_yaxis(); a1.set_xlabel('MAE (px) with 95% CI'); a1.grid(True,axis='x'); a1.set_title('(a)',loc='left')
for i,m in enumerate(ord_[1:]):
    c=st['comp'][m]; a2.errorbar(c['mean_diff'],i+1,xerr=[[c['mean_diff']-c['ci'][0]],[c['ci'][1]-c['mean_diff']]],fmt=MK[m],color='k',mfc='white',capsize=3,ms=5)
a2.axvline(0,color='k',lw=0.8); a2.set_yticks(range(6)); a2.set_yticklabels([]); a2.set_ylim(a1.get_ylim())
a2.set_xlabel('$\\Delta$MAE (ours $-$ other)'); a2.grid(True,axis='x'); a2.set_title('(b)',loc='left')
f.tight_layout(); save(f,'F_forest')
# ---------- Fig G: error vs radius bin ----------
bins=list(st['bins'].keys()); xs=np.arange(len(bins))
f,ax=plt.subplots(figsize=(3.90,3.02))
for m in M:
    ax.plot(xs,[st['bins'][b][m]['mae'] for b in bins],color='k',ls=LS[m],marker=MK[m],mfc='white' if m!='r_selfcal' else 'k',label=LAB[m])
ax.set_xticks(xs); ax.set_xticklabels([b.replace('[','[').replace(')',')') for b in bins]); ax.set_xlabel('True effective radius bin (px)'); ax.set_ylabel('MAE (px)'); ax.grid(True)
ax.legend(loc='upper left',fontsize=6.3,labelspacing=0.25,borderpad=0.3); f.tight_layout(); save(f,'G_bins')
# ---------- Fig H: signed error (Bland-Altman style) ----------
f,axs=plt.subplots(1,2,figsize=(5.17,3.54),sharey=True)
for ax,m,t in zip(axs,['r_selfcal','r_svr'],['(a) Probe-ratio EVT (ours)','(b) HOG+SVR (supervised)']):
    x=(full[m]+full.r_true)/2; y=full[m]-full.r_true
    ax.scatter(x,y,s=2,c='0.35',alpha=0.35,linewidths=0,rasterized=True); b=y.mean(); sd=y.std()
    ax.axhline(b,color='k',lw=1); ax.axhline(b+1.96*sd,color='k',ls='--',lw=0.8); ax.axhline(b-1.96*sd,color='k',ls='--',lw=0.8)
    ax.text(0.98,0.04,'bias %.2f px\nLoA $\\pm$%.1f px'%(b,1.96*sd),transform=ax.transAxes,ha='right',fontsize=7.5,bbox=dict(fc='white',ec='k',lw=0.5))
    ax.set_xlabel('Mean of estimate and truth (px)'); ax.set_title(t,fontsize=8.5,loc='left'); ax.grid(True)
axs[0].set_ylabel('$\\hat r - r$ (px)'); f.tight_layout(); save(f,'H_bland')
# ---------- Fig I: ablation CDF ----------
f,ax=plt.subplots(figsize=(3.90,2.92))
for m in ['r_evt','r_selfcal','r_svr','r_fixed']:
    e=np.sort(np.abs(full[m]-full.r_true).values); ax.plot(e,np.linspace(0,1,len(e)),color='k',ls=LS[m],label=LAB[m])
ax.set_xlim(0,15); ax.set_xlabel('Absolute radius error (px)'); ax.set_ylabel('Empirical CDF'); ax.grid(True); ax.legend(loc='lower right',fontsize=6.5); f.tight_layout(); save(f,'I_cdf')
# ---------- Fig J: sensitivity ----------
ps=json.load(open(R+'probe_sensitivity.json')); f,ax=plt.subplots(figsize=(3.90,2.81))
x=[float(k) for k in ps]; y=list(ps.values()); ax.plot(x,y,'ko-',mfc='white'); ax.axvline(5.0,color='k',ls='--',lw=0.8); ax.text(5.15,max(y)*0.92,'selected $\\sigma_p=5$',fontsize=7.5)
ax.set_xlabel('Probe strength $\\sigma_p$ (px)'); ax.set_ylabel('Calibration-corpus MAE (px)'); ax.grid(True); f.tight_layout(); save(f,'J_sensitivity')
# ---------- Fig K: clamp rate and noise/kernel family ----------
full['bin']=pd.cut(full.r_true,[0,2,4,8,15,32],right=False); cl=full.groupby('bin',observed=True).apply(lambda s:(s.r_selfcal<=1e-9).mean()*100)
f,(a1,a2)=plt.subplots(1,2,figsize=(5.17,3.42))
a1.bar(range(len(cl)),cl.values,color='0.65',edgecolor='k',hatch='///'); a1.set_xticks(range(len(cl))); a1.set_xticklabels([str(b) for b in cl.index],fontsize=7); a1.set_ylabel('Lower clamp active (%)'); a1.set_xlabel('True radius bin (px)'); a1.set_title('(a)',loc='left'); a1.grid(True,axis='y')
fam=['gaussian','disk','motion']; w=0.1
for i,m in enumerate(M):
    v=[(full[full.kernel_type==k][m]-full[full.kernel_type==k].r_true).abs().mean() for k in fam]
    a2.bar(np.arange(3)+(i-3.5)*w,v,w,color=GR[m],edgecolor='k',hatch=HT[m],lw=0.5,label=LAB[m])
a2.set_xticks(range(3)); a2.set_xticklabels(['Gaussian','Disk','Motion']); a2.set_ylabel('MAE (px)'); a2.grid(True,axis='y'); a2.set_title('(b)',loc='left'); a2.legend(fontsize=6,ncol=4,loc='upper center',bbox_to_anchor=(0.5,-0.16),columnspacing=0.8); a2.set_ylim(0,max(v)*1.9 if False else 11)
f.tight_layout(); save(f,'K_clamp_family')
# ---------- Fig L: downstream RL bars ----------
dm=['r_true','r_evt','r_selfcal','r_fixed','r_autocorr','r_spectral','r_svr','r_svr_tuned','r_svr_big']; dl=['Oracle','Naive\nEVT','Ours','Fixed','Autoc.','Spectr.','SVR','SVR\ntuned','SVR\n65 img.']
f,axs=plt.subplots(1,2,figsize=(5.17,3.54))
for ax,key,yl in zip(axs,['psnr','ssim'],['PSNR (dB)','SSIM']):
    v=[dd[f'{key}_{m}'].mean() for m in dm]; se=[dd[f'{key}_{m}'].std()/np.sqrt(len(dd)) for m in dm]
    for i,m in enumerate(dm): ax.bar(i,v[i],color='white' if m=='r_true' else GR.get(m,'0.5'),edgecolor='k',hatch=HT.get(m,''),lw=0.6)
    ax.errorbar(range(9),v,yerr=1.96*np.array(se),fmt='none',ecolor='k',capsize=2,lw=0.7)
    ax.axhline(dd[key+'_blurry'].mean(),color='k',ls=':',lw=1); ax.set_xticks(range(9)); ax.set_xticklabels(dl,fontsize=6.5,rotation=40,ha='right'); ax.set_ylabel(yl); ax.grid(True,axis='y')
    lo=min(v)-3*max(se); ax.set_ylim(max(0,lo-0.1*(max(v)-lo)),max(v)+ (max(v)-lo)*0.15)
axs[0].set_title('(a) PSNR, fixed-iteration RL',loc='left',fontsize=8.5); axs[1].set_title('(b) SSIM, fixed-iteration RL',loc='left',fontsize=8.5)
f.tight_layout(); save(f,'L_rl')
# ---------- Fig M: alt solvers ----------
f,axs=plt.subplots(1,2,figsize=(5.17,3.54))
for ax,sv,t in zip(axs,['wiener','rladapt'],['(a) Wiener deconvolution','(b) Adaptive-iteration RL']):
    v=[alt[f'psnr_{sv}_{m}'].mean() for m in dm]; se=[alt[f'psnr_{sv}_{m}'].std()/np.sqrt(len(alt)) for m in dm]
    for i,m in enumerate(dm): ax.bar(i,v[i],color='white' if m=='r_true' else GR.get(m,'0.5'),edgecolor='k',hatch=HT.get(m,''),lw=0.6)
    ax.errorbar(range(9),v,yerr=1.96*np.array(se),fmt='none',ecolor='k',capsize=2,lw=0.7); ax.set_xticks(range(9)); ax.set_xticklabels(dl,fontsize=6.5,rotation=40,ha='right'); ax.set_ylabel('PSNR (dB)'); ax.set_title(t,loc='left',fontsize=8.5); ax.set_ylim(min(v)-1,max(v)+0.8); ax.grid(True,axis='y')
f.tight_layout(); save(f,'M_solvers')
# ---------- Fig N: DRIVE ----------
_d=json.load(open(BASE+'new/drive2.json')); dr=dict(mae_natural=_d['mae_nat'],mae_recalibrated=_d['mae_rec'],mae_fixed3=_d['mae_fixed3']); f,ax=plt.subplots(figsize=(3.90,2.92))
ax.bar([0,1,2],[dr['mae_natural'],dr['mae_recalibrated'],dr['mae_fixed3']],color=['0.8','0.35','0.95'],edgecolor='k',hatch='//',width=0.55); ax.set_xticks([0,1,2]); ax.set_xticklabels(['Natural-image\nconstants','Recalibrated on\n20 DRIVE images','Fixed\n$r=3$'],fontsize=7)
for i,v in enumerate([dr['mae_natural'],dr['mae_recalibrated'],dr['mae_fixed3']]): ax.text(i,v+0.3,'%.2f'%v,ha='center',fontsize=8)
ax.set_ylabel('MAE (px), $n=160$'); ax.set_ylim(0,19); ax.grid(True,axis='y'); f.tight_layout(); save(f,'N_drive')
print('figs ok')
# ---------- Fig O: probe-ratio response and conditioning ----------
tau,gam=cc['tau'],cc['gamma']; dl=5.0*np.sqrt(2); c=(dl/tau)**2
rr=np.linspace(0.05,30,600); a=1+(rr/tau)**2; rho=(1+c/a)**(-gam)
amp=tau*a*(a+c)/(2*gam*c*rho*np.sqrt(a-1))
f,(a1,a2)=plt.subplots(1,2,figsize=(5.17,3.17))
a1.plot(rr,rho,'k-'); a1.set_xlabel('Blur effective radius $r$ (px)'); a1.set_ylabel('Probe ratio $\\rho(r)=\\Delta_2/\\Delta_1$'); a1.grid(True); a1.set_title('(a)',loc='left')
a1.axhline((1+c)**(-gam),color='k',ls=':',lw=0.7); a1.axhline(1,color='k',ls=':',lw=0.7); a1.text(15,(1+c)**(-gam)+0.006,'$\\rho(0)=(1+c)^{-\\gamma}$',fontsize=7.5)
a2.semilogy(rr,amp,'k-'); a2.set_xlabel('Blur effective radius $r$ (px)'); a2.set_ylabel('$|\\partial\\hat r/\\partial\\rho|$ (px per unit $\\rho$)'); a2.grid(True,which='both'); a2.set_title('(b)',loc='left')
f.tight_layout(); save(f,'O_conditioning')
print('c=',c,'rho0=',(1+c)**(-gam),'amp at 1,4,8,15:',[float(np.interp(x,rr,amp)) for x in (1,4,8,15)],'tau,gam',tau,gam)
# ---------- Fig P: window size / multi-scale ----------
import os
ms=json.load(open(BASE+'new/results/ms_stats.json')) if os.path.exists(BASE+'new/results/ms_stats.json') else None
if ms:
    cfg=['r_w3','r_w5','r_w9','r_ms']; cl=['$w{=}3$','$w{=}5$','$w{=}9$','Multi-scale']
    dsn=['Set14','BSD100','Urban100','CBSD68']; f,ax=plt.subplots(figsize=(3.90,2.92)); w=0.2
    for i,c in enumerate(cfg):
        ax.bar(np.arange(4)+(i-1.5)*w,[ms['per_ds'][d][c] for d in dsn],w,color=['0.9','0.25','0.6','1.0'][i],edgecolor='k',hatch=['','','//','xx'][i],lw=0.6,label=cl[i])
    ax.set_xticks(range(4)); ax.set_xticklabels(dsn,fontsize=7.5); ax.set_ylabel('MAE (px)'); ax.set_ylim(1.5,3.9); ax.grid(True,axis='y'); ax.legend(fontsize=6.5,ncol=4,loc='upper left',columnspacing=0.8,handlelength=1.2); f.tight_layout(); save(f,'P_window')
    
# ---------- Fig Q: calibration-set size and per-family law ----------
import os
if os.path.exists(BASE+'new/calib_studies.json'):
    cs=json.load(open(BASE+'new/calib_studies.json')); E1=cs['E1']; ns=sorted(int(k) for k in E1)
    f,(a1,a2)=plt.subplots(1,2,figsize=(5.17,3.17),gridspec_kw={'width_ratios':[1.15,1]})
    mu=np.array([E1[str(n)]['mae_mean'] for n in ns]); sd=np.array([E1[str(n)]['mae_sd'] for n in ns])
    a1.errorbar(ns,mu,yerr=sd,fmt='ko-',mfc='white',capsize=3); a1.set_xscale('log'); a1.minorticks_off(); tk=[n for n in ns if n in (3,10,25,65)]; a1.set_xticks(tk); a1.set_xticklabels([str(n) for n in tk])
    a1.axhline(st['mae']['r_fixed']['mae'],color='k',ls=':',lw=0.9); a1.text(ns[0],st['mae']['r_fixed']['mae']+0.03,'fixed $r=3$',fontsize=7)
    a1.set_xlabel('Calibration images $n$'); a1.set_ylabel('Image-mean MAE (px)'); a1.grid(True); a1.set_title('(a)',loc='left')
    fams=['gaussian','disk','motion']; w=0.25; E2=cs['E2']
    for i,k in enumerate(['gaussian','disk','motion','mixed']):
        a2.bar(np.arange(3)+(i-1.5)*0.2,[E2[f][k] for f in fams],0.2,color=['0.25','0.6','0.9','1.0'][i],edgecolor='k',hatch=['','//','..','xx'][i],lw=0.6,label={'gaussian':'Gaussian-cal.','disk':'Disk-cal.','motion':'Line-cal.','mixed':'Mixed-cal.'}[k])
    a2.set_xticks(range(3)); a2.set_xticklabels(['Gaussian','Disk','Line']); a2.set_ylabel('MAE (px)'); a2.set_xlabel('Evaluation kernel family'); a2.grid(True,axis='y'); a2.legend(fontsize=6.3,ncol=2,loc='upper left'); a2.set_title('(b)',loc='left'); a2.set_ylim(0,max(max(E2[f][k] for k in ['gaussian','disk','motion','mixed']) for f in fams)*1.35)
    f.tight_layout(); save(f,'Q_calibration')
# ---------- Fig R: RL iteration sweep ----------
dsx=json.load(open(R+'down_stats.json')) if os.path.exists(R+'down_stats.json') else None
if dsx:
    f,ax=plt.subplots(figsize=(3.90,3.02)); it=np.arange(1,61)
    sty={'oracle':('k','-'),'selfcal':('k','--'),'fixed':('0.45',':'),'evt':('0.45','-.'),'svr_tuned':('0.2',(0,(1,1))),'autocorr':('0.65','-')}
    lab={'oracle':'Oracle','selfcal':'Ours','fixed':'Fixed $r{=}3$','evt':'Naive EVT','svr_tuned':'SVR tuned','autocorr':'Autocorr.'}
    for m,(c,l) in sty.items(): ax.plot(it,dsx['sweep'][m],color=c,ls=l,label=lab[m])
    ax.axvline(25,color='k',lw=0.5); ax.text(25.8,ax.get_ylim()[0]+0.1,'$T{=}25$',fontsize=7)
    ax.axhline(dsx['blurry']['psnr'],color='k',lw=0.6,ls=(0,(1,3))); ax.text(35,dsx['blurry']['psnr']+0.08,'blurry input',fontsize=7)
    ax.set_xlabel('Richardson--Lucy iterations $T$'); ax.set_ylabel('Mean PSNR (dB)'); ax.grid(True); ax.set_ylim(13.0,24.8); ax.legend(fontsize=6.3,ncol=3,loc='lower left',columnspacing=0.8); f.tight_layout(); save(f,'R_sweep')
    # ---------- Fig S: visual example ----------
    import pickle
    ex=pickle.load(open(BASE+'new/down_Set14.pkl','rb'))['examples']; iid=list(ex.keys())[0]; e=ex[iid]
    panels=[('Sharp','sharp'),('Blurry','blurry'),('Oracle','oracle'),('Ours','selfcal'),('Fixed $r{=}3$','fixed'),('SVR tuned','svr_tuned')]
    f,axs=plt.subplots(2,6,figsize=(5.17,3.05))
    H,W=e['sharp'].shape[:2]; y0,x0=H//2-40,W//2-40
    for j,(t,k) in enumerate(panels):
        axs[0,j].imshow(e[k]); axs[0,j].set_title(t,fontsize=7); axs[0,j].axis('off')
        axs[1,j].imshow(e[k][y0:y0+80,x0:x0+80],interpolation='nearest'); axs[1,j].axis('off')
    axs[0,0].add_patch(Rectangle((x0,y0),80,80,fill=False,ec='w',lw=0.8))
    f.tight_layout(pad=0.3); save(f,'S_visual')
print('figs2 ok')
