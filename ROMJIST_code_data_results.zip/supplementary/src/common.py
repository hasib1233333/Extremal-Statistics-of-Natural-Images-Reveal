import sys, os, glob, json, time
BASE=__import__('os').environ.get('RP_BASE','.').rstrip('/')+'/'
SRC=BASE+'supp2/src'
sys.path.insert(0,SRC)
import numpy as np
import core, run_kernel_size_experiment as rk
os.chdir(BASE+'work')   # data/ lives here
PROBE_SIGMA=5.0
def pool_files():
    """Images NOT used in evaluation: Set5 + BSD100 images not in the evaluation sample."""
    set5=sorted(glob.glob('data/selfexsr/data/Set5/image_SRF_2/*_HR.png'))
    bsd=sorted(glob.glob(rk.DATASET_PATHS['BSD100']))
    cr=np.random.default_rng(1234); ci=cr.choice(len(bsd),size=20,replace=False)
    calib=[bsd[i] for i in sorted(ci)]
    rest=[f for f in bsd if f not in set(calib)]
    rng=np.random.default_rng(rk.RNG_SEED)   # same draw as the evaluation run for BSD100
    idx=rng.choice(len(rest),size=rk.N_SAMPLE['BSD100'],replace=False); idx.sort()
    ev=set(rest[i] for i in idx)
    unused=[f for f in rest if f not in ev]
    return set5, calib, unused, ev
