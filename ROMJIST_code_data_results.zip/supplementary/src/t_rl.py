from common import *
from scipy.signal import fftconvolve
f=sorted(glob.glob(rk.DATASET_PATHS['Set14']))[3]; sharp=rk.load_resized(f,dim=256)
def blur_reflect(img,k):
    ph,pw=k.shape[0]//2,k.shape[1]//2
    p=np.pad(img,((ph,ph),(pw,pw),(0,0)),mode='reflect')
    return np.stack([fftconvolve(p[:,:,c],k,mode='valid') for c in range(3)],2)
def rl_reflect(b,k,n):
    ph,pw=k.shape[0]//2,k.shape[1]//2
    P=np.pad(b,((ph,ph),(pw,pw),(0,0)),mode='reflect'); est=P.copy(); kf=k[::-1,::-1]
    for _ in range(n):
        for c in range(3):
            conv=fftconvolve(est[:,:,c],k,mode='same')+1e-6
            est[:,:,c]=np.clip(est[:,:,c]*fftconvolve(P[:,:,c]/conv,kf,mode='same'),0,1)
    return est[ph:ph+b.shape[0],pw:pw+b.shape[1]]
def psnr_c(a,b,m=16): return core.psnr(a[m:-m,m:-m],b[m:-m,m:-m])
for fam,p in [('gaussian',2),('gaussian',5),('gaussian',10),('disk',5),('motion',15)]:
    k=core.gaussian_kernel(p)[0] if fam=='gaussian' else core.disk_kernel(p)[0] if fam=='disk' else core.motion_kernel(length=p,angle_deg=0.0)[0]
    b=blur_reflect(sharp,k); 
    print(fam,p,'blurry',round(psnr_c(b,sharp),2),[ (n,round(psnr_c(rl_reflect(b,k,n),sharp),2)) for n in (5,25,60)])
