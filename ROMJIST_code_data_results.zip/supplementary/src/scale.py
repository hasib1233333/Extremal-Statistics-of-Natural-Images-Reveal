from common import *
import pandas as pd, cv2
C=json.load(open(BASE+'new/calib_params.json'))
sc=core.SelfCalibratingEVT(tau=C['tau'],gamma=C['gamma'],w=5,probe_sigma=PROBE_SIGMA)
res={}
# runtime vs image size (one image resized; median of 5)
img=rk.load_resized(sorted(glob.glob(rk.DATASET_PATHS['Set14']))[0],dim=1024)
big=core.apply_blur(cv2.resize(img,(1024,int(1024*img.shape[0]/img.shape[1]))),core.gaussian_kernel(3)[0])
rt={}
for d in [128,256,512,1024]:
    b=cv2.resize(big,(d,int(d*big.shape[0]/big.shape[1])),interpolation=cv2.INTER_AREA)
    ts=[]
    for _ in range(5):
        t=time.time(); sc.estimate_radius(b); ts.append(time.time()-t)
    t2=[]
    for _ in range(5):
        t=time.time(); core.baseline_fixed(b); core.baseline_autocorrelation(b); t2.append(time.time()-t)
    rt[d]=dict(selfcal_ms=1e3*float(np.median(ts)),pixels=int(b.shape[0]*b.shape[1]))
res['runtime']=rt
# resolution robustness: same blur kernels (in px) at different working resolutions, Set14, noise free
rows=[]
grid={'gaussian':[1,2,3,4,5,6,8,10],'disk':[1,2,3,4,5,6,8,10],'motion':[3,6,9,12,15,18,24,30]}
rng=np.random.default_rng(31)
files=sorted(glob.glob(rk.DATASET_PATHS['Set14']))
for dim in [128,256,512]:
    for f in files:
        im=rk.load_resized(f,dim=dim)
        for kt,ps in grid.items():
            for p in ps:
                k,r=rk.build_kernel(kt,p,rng); b=core.apply_blur(im,k)
                rows.append(dict(dim=dim,kernel_type=kt,r_true=r,r_hat=sc.estimate_radius(b),image=os.path.basename(f)))
df=pd.DataFrame(rows); df['err']=(df.r_hat-df.r_true).abs(); df.to_csv(BASE+'new/resolution.csv',index=False)
res['resolution']={int(d):dict(mae=float(g.err.mean()),bias=float((g.r_hat-g.r_true).mean()),n=len(g)) for d,g in df.groupby('dim')}
json.dump(res,open(BASE+'new/scale.json','w'),indent=1); print(json.dumps(res,indent=1))
