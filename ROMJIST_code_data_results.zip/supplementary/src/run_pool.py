# Depth curves of pool images (disjoint from evaluation) for three kernel families,
# plus features/labels for supervised baselines.
from common import *
import pickle
set5,calib,unused,ev=pool_files()
files=set5+calib+unused
print(len(set5),len(calib),len(unused),len(files),flush=True)
imgs=[rk.load_resized(f) for f in files]
radii_g=[0,0.5,1,1.5,2,2.5,3,3.5,4,5,6,7,8,10,12]
fams={'gaussian':[0.35*0+x/1.0 for x in radii_g if x>0]}
# parameters per family (native parameters), r_eff computed numerically
params={'gaussian':[0.5,1,1.5,2,2.5,3,3.5,4,5,6,7,8,10,12],'disk':[1,1.5,2,3,4,5,6,8,10,12,16],'motion':[2,4,6,9,12,15,18,24,30]}
rng=np.random.default_rng(99)
out={'files':files,'n_set5':len(set5),'n_calib':len(calib),'fam':{}}
for fam,ps in params.items():
    R=[];D=[[] for _ in imgs]; feats=[];labels=[];imgidx=[]
    for p in ps:
        ks=[]
        for i,img in enumerate(imgs):
            k,r=rk.build_kernel(fam,p,rng)
            b=core.apply_blur(img,k)
            D[i].append(core.dark_channel_depth(b,5)[0])
            feats.append(core.hog_features(b)); labels.append(r); imgidx.append(i)
            ks.append(r)
        R.append(float(np.mean(ks)))
    D0=[core.dark_channel_depth(img,5)[0] for img in imgs]
    out['fam'][fam]=dict(r=np.array([0.0]+R),depth=np.array([[D0[i]]+D[i] for i in range(len(imgs))]),
                         X=np.array(feats),y=np.array(labels),g=np.array(imgidx))
    print(fam,'done',flush=True)
# sharp images as r=0 samples for HOG too
out['X0']=np.array([core.hog_features(img) for img in imgs])
pickle.dump(out,open(BASE+'new/pool.pkl','wb'))
