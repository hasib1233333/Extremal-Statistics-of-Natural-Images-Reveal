import glob,json,sys,time,numpy as np,pandas as pd
from scipy import optimize
sys.path.insert(0,'../supp2/src'); import core
C=json.load(open('calib_params.json')); tau,gam=C['tau'],C['gamma']; RMAX=30.0
mp=pd.concat([pd.read_csv(f) for f in sorted(glob.glob('mp_*.csv'))],ignore_index=True)
full=pd.read_csv('results/kernel_size_ALL.csv'); key=['dataset','image','kernel_type','kernel_param','noise']
m=mp.merge(full[key+['r_selfcal','r_fixed','r_svr_tuned']],on=key); m['img']=m.dataset+'/'+m.image; rt=m.r_true.values; base=m.r_selfcal.values
out={}
# ---- (A) shifted radius distributions: constant tuned on original grid vs ours vs fixed vs SVR-tuned (trained on original) ----
c0=float(np.median(rt)); b=np.digitize(rt,[2,4,8]); 
def wmae(pred,w): return float((np.abs(pred-rt)*w).sum()/w.sum())
dists={'Original grid':np.ones(len(rt)),'Small radii (r<4) x4':np.where(rt<4,4.0,1.0),'Large radii (r>=8) x4':np.where(rt>=8,4.0,1.0),'Only r>=5':(rt>=5).astype(float),'Only r<3':(rt<3).astype(float),'Uniform over the four bins':np.array([1/np.mean(b==k) for k in range(4)])[b]}
A={}
for n,w in dists.items():
    # oracle-tuned constant for the new distribution (weighted median) for reference
    o=np.argsort(rt); cw=rt[o][np.searchsorted(np.cumsum(w[o]),0.5*w.sum())]
    A[n]=dict(ours=wmae(base,w),const_orig=wmae(np.full(len(rt),c0),w),const_retuned=wmae(np.full(len(rt),cw),w),fixed3=wmae(m.r_fixed.values,w),svr_tuned=wmae(m.r_svr_tuned.values,w))
out['shift']=A
for n,v in A.items(): print(n,{k:round(x,2) for k,x in v.items()})
# ---- (B) analytic multi-probe joint inversion in log rho ----
PS=[3.0,5.0,8.0]; dl=[core.gaussian_kernel(sigma=s)[1] for s in PS]
L=np.stack([np.log(np.clip(m['d2_%g'%s].values/np.maximum(m.d1.values,1e-8),1e-6,1-1e-6)) for s in PS],1)
rg=np.linspace(0,RMAX,601)
Mg=np.stack([-gam*(np.log(1+(rg**2+d**2)/tau**2)-np.log(1+rg**2/tau**2)) for d in dl],1)  # model log rho (601x3)
# residual scale per probe, from calibration-like fit: use robust std of (L - model at true r) on a *disjoint half* of images
imgs=m.img.unique(); half=np.isin(m.img.values,imgs[::2])
Mt=np.stack([-gam*(np.log(1+(rt**2+d**2)/tau**2)-np.log(1+rt**2/tau**2)) for d in dl],1); sd=(L[half]-Mt[half]).std(0); out['probe_resid_sd']=sd.tolist()
def inv(W):
    cost=(((L[:,None,:]-Mg[None,:,:])**2)*W[None,None,:]).sum(2); return rg[cost.argmin(1)]
est={'single probe sigma=5 (grid)':inv(np.array([0,1,0.])),'equal weights, 3 probes':inv(np.ones(3)),'inverse-variance weights (calibrated on other half)':inv(1/sd**2)}
te=~half; B={}
for n,e in est.items(): B[n]=dict(mae_testhalf=float(np.abs(e[te]-rt[te]).mean()),mae_all=float(np.abs(e-rt).mean()),bias=float((e-rt).mean()))
out['joint']=B; out['single_mae_testhalf']=float(np.abs(base[te]-rt[te]).mean())
for n,v in B.items(): print(n,{k:round(x,3) for k,x in v.items()})
# ---- (C) runtime profile at 256 px ----
import cv2
from scipy import ndimage
img=np.random.default_rng(0).random((192,256,3)); k=core.gaussian_kernel(sigma=5.0)[0]
def tm(f,n=20):
    f(); t=time.time(); [f() for _ in range(n)]; return (time.time()-t)/n*1000
src=open('../supp2/src/core.py').read()
out['runtime_ms']=dict(probe_blur=tm(lambda:core.apply_blur(img,k)),depth=tm(lambda:core.dark_channel_depth(img,5)),full=tm(lambda:core.SelfCalibratingEVT(tau=tau,gamma=gam,w=5,probe_sigma=5.0).estimate_radius(img)))
print(out['runtime_ms'])
json.dump(out,open('results/extras.json','w'),indent=1)
