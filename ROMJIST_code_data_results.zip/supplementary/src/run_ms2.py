from common import *
import pandas as pd
from law import *
ds=sys.argv[1]; out=sys.argv[2]
set5,calib,unused,ev=pool_files(); bsd_calib=set(calib)
refimgs=[rk.load_resized(f) for f in set5+calib]
sig=[0.5,1,1.5,2,2.5,3,3.5,4,5,6,7,8,10,12]
ks=[core.gaussian_kernel(sigma=s) for s in sig]; rc=np.array([0.0]+[k[1] for k in ks])
blur=[[core.apply_blur(im,k[0]) for im in refimgs] for k in ks]
SC={}
for w in (3,5,9):
    d=[np.mean([core.dark_channel_depth(im,w)[0] for im in refimgs])]+[np.mean([core.dark_channel_depth(b,w)[0] for b in bl]) for bl in blur]
    d0,t,g=fit_law(rc,np.array(d)); SC[w]=core.SelfCalibratingEVT(tau=t,gamma=g,w=w,probe_sigma=PROBE_SIGMA); print(w,t,g,flush=True)
rng=np.random.default_rng(rk.RNG_SEED)
files=sorted(glob.glob(rk.DATASET_PATHS[ds]))
if ds=='BSD100': files=[f for f in files if f not in bsd_calib]
n=rk.N_SAMPLE[ds]
if n is not None and n<len(files):
    idx=rng.choice(len(files),size=n,replace=False); idx.sort(); files=[files[i] for i in idx]
grid={'gaussian':[1,2,3,4,5,6,8,10],'disk':[1,2,3,4,5,6,8,10],'motion':[3,6,9,12,15,18,24,30]}
rows=[]
for f in files:
    img=rk.load_resized(f); iid=os.path.basename(f)
    for kt,ps in grid.items():
        for p in ps:
            k,rt=rk.build_kernel(kt,p,rng)
            for noise in (0.0,0.02):
                b=core.apply_blur(img,k,noise_sigma=noise,rng=rng)
                est={w:SC[w].estimate_radius(b) for w in (3,5,9)}
                rows.append(dict(dataset=ds,image=iid,kernel_type=kt,kernel_param=p,noise=noise,r_true=rt,
                  r_w3=est[3],r_w5=est[5],r_w9=est[9],r_ms=float(np.median([est[3],est[5],est[9]]))))
    print(ds,iid,len(rows),flush=True)
pd.DataFrame(rows).to_csv(out,index=False)
