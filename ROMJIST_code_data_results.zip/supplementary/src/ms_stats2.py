import glob,json,math,numpy as np,pandas as pd
from scipy import stats
R='results/'
ms=pd.concat([pd.read_csv(f) for f in sorted(glob.glob('ms2_*.csv'))],ignore_index=True)
full=pd.read_csv(R+'kernel_size_ALL.csv')
key=['dataset','image','kernel_type','kernel_param','noise']
m=full[key+['r_true','r_selfcal']].merge(ms,on=key,suffixes=('','_ms'))
print(len(ms),len(m),'max |r_w5 - r_selfcal|',np.abs(m.r_w5-m.r_selfcal).max(),'true diff',np.abs(m.r_true-m.r_true_ms).max())
m['img']=m.dataset+'/'+m.image
rng=np.random.default_rng(99); imgs=m.img.unique(); idx={i:np.where(m.img.values==i)[0] for i in imgs}
def boot(fn,B=2000):
    o=[]
    for _ in range(B):
        p=rng.choice(len(imgs),len(imgs)); o.append(fn(np.concatenate([idx[imgs[j]] for j in p])))
    return np.percentile(o,[2.5,97.5])
E={c:np.abs(m[c].values-m.r_true.values) for c in ['r_w3','r_w5','r_w9','r_ms']}
res={}
for c in E: res[c]=dict(mae=float(E[c].mean()),ci=list(boot(lambda ii,c=c:E[c][ii].mean())))
for c in ['r_w3','r_w9','r_ms']:
    d=E[c]-E['r_w5']; w=stats.wilcoxon(pd.Series(E[c]).groupby(m.img.values).mean().values,pd.Series(E['r_w5']).groupby(m.img.values).mean().values)
    res[c]['vs_w5']=dict(diff=float(d.mean()),ci=list(boot(lambda ii:d[ii].mean())),p=float(w.pvalue))
# vs svr
svr=np.abs(full.set_index(key).loc[m.set_index(key).index,'r_svr_tuned'].values-m.r_true.values)
d=E['r_ms']-svr; res['ms_vs_svr_tuned']=dict(diff=float(d.mean()),ci=list(boot(lambda ii:d[ii].mean())))
# per dataset
res['per_ds']={ds:{c:float(E[c][m.dataset.values==ds].mean()) for c in E} for ds in m.dataset.unique()}
# rmse, pearson ms
res['ms_rmse']=float(np.sqrt(((m.r_ms-m.r_true)**2).mean())); res['ms_pearson']=float(np.corrcoef(m.r_ms,m.r_true)[0,1])
res['w5_pearson']=float(np.corrcoef(m.r_w5,m.r_true)[0,1])
json.dump(res,open('results/ms_stats.json','w'),indent=1)
print(json.dumps(res,indent=1))
def pv(p):
    e=int(math.floor(math.log10(p)));return '$%.1f\\times10^{%d}$'%(p/10**e,e)
N={'r_w3':'Single scale, $w=3$','r_w5':'Single scale, $w=5$ (default)','r_w9':'Single scale, $w=9$','r_ms':'Multi-scale median, $w\\in\\{3,5,9\\}$'}
rows=[]
for c in ['r_w3','r_w5','r_w9','r_ms']:
    v=res[c]; vs='--' if c=='r_w5' else '%+.2f [%+.2f, %+.2f]'%(v['vs_w5']['diff'],*v['vs_w5']['ci'])
    pp='--' if c=='r_w5' else pv(v['vs_w5']['p'])
    rows.append('%s & %.2f [%.2f, %.2f] & %s & %s \\\\'%(N[c],v['mae'],*v['ci'],vs,pp))
open('tex/table_ms.tex','w').write('\\begin{tabular}{lccc}\n\\toprule\nConfiguration & MAE (px) [95\\% CI] & $\\Delta$MAE vs.\\ $w{=}5$ [95\\% CI] & Wilcoxon $p$ \\\\\n\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\n\\end{tabular}\n')
