# Directional-probe signatures on the same 6432 instances (same rng sequence as run_all.py / mp_run.py).
from common import *
import pandas as pd
ds=sys.argv[1]; out=sys.argv[2]
def aniso(sx,sy,th):
    h=int(np.ceil(4*max(sx,sy))); y,x=np.mgrid[-h:h+1,-h:h+1].astype(float); t=np.deg2rad(th)
    u=x*np.cos(t)+y*np.sin(t); v=-x*np.sin(t)+y*np.cos(t); k=np.exp(-0.5*((u/sx)**2+(v/sy)**2)); return k/k.sum()
PROBES={'h':aniso(6,0.7,0),'v':aniso(6,0.7,90),'d45':aniso(6,0.7,45),'d135':aniso(6,0.7,135)}
def cov(k):
    y,x=np.indices(k.shape); k=k/k.sum(); cy=(k*y).sum(); cx=(k*x).sum()
    return (k*(x-cx)**2).sum(),(k*(y-cy)**2).sum(),(k*(x-cx)*(y-cy)).sum()
rng=np.random.default_rng(rk.RNG_SEED)
set5,calib,unused,ev=pool_files(); bsd_calib=set(calib)
files=sorted(glob.glob(rk.DATASET_PATHS[ds]))
if ds=='BSD100': files=[f for f in files if f not in bsd_calib]
n=rk.N_SAMPLE[ds]
if n is not None and n<len(files):
    idx=rng.choice(len(files),size=n,replace=False); idx.sort(); files=[files[i] for i in idx]
grid={'gaussian':[1,2,3,4,5,6,8,10],'disk':[1,2,3,4,5,6,8,10],'motion':[3,6,9,12,15,18,24,30]}
rows=[]
for f in files:
    img=rk.load_resized(f); iid=os.path.basename(f)
    for kt,ps in grid.items():
        for p in ps:
            k,rt=rk.build_kernel(kt,p,rng); sxx,syy,sxy=cov(k)
            for noise in (0.0,0.02):
                b=core.apply_blur(img,k,noise_sigma=noise,rng=rng)
                row=dict(dataset=ds,image=iid,kernel_type=kt,kernel_param=p,noise=noise,r_true=rt,sxx=sxx,syy=syy,sxy=sxy,d1=core.dark_channel_depth(b,5)[0])
                for nm,pk in PROBES.items(): row['d2_'+nm]=core.dark_channel_depth(core.apply_blur(b,pk),5)[0]
                rows.append(row)
    print(ds,iid,len(rows),flush=True)
pd.DataFrame(rows).to_csv(out,index=False)
