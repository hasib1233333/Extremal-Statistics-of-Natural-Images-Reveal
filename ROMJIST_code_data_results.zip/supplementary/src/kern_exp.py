# (1) matched-effective-radius kernels of different shapes; (2) robustness: Poisson-Gaussian noise, JPEG q=50, spatially varying blur.
from common import *
import pandas as pd, cv2
C=json.load(open(BASE+'new/calib_params.json'))
sc=core.SelfCalibratingEVT(tau=C['tau'],gamma=C['gamma'],w=5,probe_sigma=PROBE_SIGMA)
def reff(k):
    k=k/k.sum(); y,x=np.indices(k.shape); cy=(k*y).sum(); cx=(k*x).sum(); return float(np.sqrt((k*((x-cx)**2+(y-cy)**2)).sum()))
def aniso(r,asp,th):
    sy=r/np.sqrt(1+asp**2); sx=asp*sy; h=int(np.ceil(4*max(sx,sy))); y,x=np.mgrid[-h:h+1,-h:h+1].astype(float)
    t=np.deg2rad(th); u=x*np.cos(t)+y*np.sin(t); v=-x*np.sin(t)+y*np.cos(t)
    k=np.exp(-0.5*((u/sx)**2+(v/sy)**2)); return k/k.sum()
def make(name,r):
    if name=='Gaussian': return core.gaussian_kernel(sigma=r/np.sqrt(2))[0]
    if name=='Disk': return core.disk_kernel(radius=np.sqrt(2)*r)[0]
    if name.startswith('Line'): return core.motion_kernel(length=np.sqrt(12)*r,angle_deg=float(name[4:]))[0]
    a,th=name[3:].split('_'); return aniso(r,float(a),float(th))
names=['Gaussian','Disk','Line0','Line45','Line90','Ani2_0','Ani2_45','Ani2_90','Ani4_0','Ani4_90']
set5,calib,unused,ev=pool_files()
files=sorted(glob.glob(rk.DATASET_PATHS['Set14']))+sorted(glob.glob(rk.DATASET_PATHS['BSD100']))
files=[f for f in files if f not in set(calib)]
rng0=np.random.default_rng(555); sel=list(sorted(glob.glob(rk.DATASET_PATHS['Set14'])))+list(rng0.choice([f for f in files if 'img_' in f and f not in sorted(glob.glob(rk.DATASET_PATHS['Set14']))],size=16,replace=False))
imgs=[(os.path.basename(f),rk.load_resized(f)) for f in sel]
print(len(imgs),flush=True)
def d12(b):
    d1=core.dark_channel_depth(b,5)[0]; d2=core.dark_channel_depth(core.apply_blur(b,sc._probe_kernel),5)[0]; return d1,d2
rows=[]
rng=np.random.default_rng(2026)
for r in (2,4,6,8):
    ks={n:make(n,r) for n in names}
    for n,k in ks.items():
        rt=reff(k)
        for iid,im in imgs:
            b=core.apply_blur(im,k); d1,d2=d12(b)
            rows.append(dict(exp='matched',kernel=n,r_nom=r,r_true=rt,image=iid,rho=d2/d1,r_hat=sc.estimate_radius(b)))
    print('matched r',r,flush=True)
pd.DataFrame(rows).to_csv('kern_matched.csv',index=False)
# robustness
rows=[]
def pg(b,P,s):
    y=rng.poisson(np.clip(b,0,1)*P)/P+rng.normal(0,s,b.shape); return np.clip(y,0,1)
def jpg(b,q):
    return cv2.imdecode(cv2.imencode('.jpg',(b*255).round().astype(np.uint8),[cv2.IMWRITE_JPEG_QUALITY,q])[1],cv2.IMREAD_COLOR)[:,:,::-1].astype(np.float64)/255.0
conds={'clean':lambda b:b,'Poisson-Gaussian P=1000, s=0.005':lambda b:pg(b,1000,0.005),'Poisson-Gaussian P=100, s=0.01':lambda b:pg(b,100,0.01),'JPEG q=75':lambda b:jpg(b,75),'JPEG q=50':lambda b:jpg(b,50),'JPEG q=30':lambda b:jpg(b,30)}
for r in (2,4,6,8):
    for n in ('Gaussian','Disk','Line0'):
        k=make(n,r); rt=reff(k)
        for iid,im in imgs:
            b0=core.apply_blur(im,k)
            for cn,fn in conds.items():
                rows.append(dict(exp='robust',cond=cn,kernel=n,r_true=rt,image=iid,r_hat=sc.estimate_radius(fn(b0))))
    print('robust r',r,flush=True)
# spatially varying: horizontal blend of Gaussian blur radius r (left) and 2r (right)
W=None
for r in (1.5,3,4.5):
    k1=make('Gaussian',r); k2=make('Gaussian',2*r)
    for iid,im in imgs:
        b1=core.apply_blur(im,k1); b2=core.apply_blur(im,k2); h,w=im.shape[:2]; a=np.linspace(0,1,w)[None,:,None]
        b=(1-a)*b1+a*b2
        rows.append(dict(exp='varying',cond='left->right r..2r',kernel='Gaussian',r_true=r,r_true2=2*r,image=iid,r_hat=sc.estimate_radius(b)))
    print('varying',r,flush=True)
pd.DataFrame(rows).to_csv('kern_robust.csv',index=False)
