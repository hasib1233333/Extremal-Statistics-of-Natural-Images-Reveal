# Full upstream run with the corrected calibration (abscissa = effective radius) and corrected SVR labels.
from common import *
import pickle, pandas as pd, cv2
ds=sys.argv[1]; out=sys.argv[2]
C=json.load(open(BASE+'new/calib_params.json')); S=pickle.load(open(BASE+'new/svr.pkl','rb'))
selfcal=core.SelfCalibratingEVT(tau=C['tau'],gamma=C['gamma'],w=5,probe_sigma=PROBE_SIGMA)
naive=core.EVTCalibration(w=5); naive.delta0,naive.tau,naive.gamma=C['delta0'],C['tau'],C['gamma']
pk,dr=core.gaussian_kernel(sigma=PROBE_SIGMA)
rng=np.random.default_rng(rk.RNG_SEED)
set5,calib,unused,ev=pool_files(); bsd_calib=set(calib)
files=sorted(glob.glob(rk.DATASET_PATHS[ds]))
if ds=='BSD100': files=[f for f in files if f not in bsd_calib]
n=rk.N_SAMPLE[ds]
if n is not None and n<len(files):
    idx=rng.choice(len(files),size=n,replace=False); idx.sort(); files=[files[i] for i in idx]
grid={'gaussian':[1,2,3,4,5,6,8,10],'disk':[1,2,3,4,5,6,8,10],'motion':[3,6,9,12,15,18,24,30]}
def T(f,*a):
    t=time.time(); v=f(*a); return v,time.time()-t
def svr_pred(m,b): return float(max(m.predict(core.hog_features(b).reshape(1,-1))[0],0.0))
rows=[]
for f in files:
    img=rk.load_resized(f); iid=os.path.basename(f)
    for kt,ps in grid.items():
        for p in ps:
            k,rt=rk.build_kernel(kt,p,rng)
            for noise in (0.0,0.02):
                b=core.apply_blur(img,k,noise_sigma=noise,rng=rng)
                r_sc,t_sc=T(selfcal.estimate_radius,b)
                r_ev,t_ev=T(naive.estimate_radius,b)
                r_fx,t_fx=T(core.baseline_fixed,b)
                r_ac,t_ac=T(core.baseline_autocorrelation,b)
                r_sp,t_sp=T(core.baseline_spectral_slope,b)
                r_sv,t_sv=T(svr_pred,S['svr_orig'],b)
                r_st=svr_pred(S['svr_tuned'],b); r_sb=svr_pred(S['svr_big'],b)
                d1=core.dark_channel_depth(b,5)[0]; d2=core.dark_channel_depth(core.apply_blur(b,pk),5)[0]
                bj=cv2.imdecode(cv2.imencode('.jpg',(b*255).round().astype(np.uint8),[cv2.IMWRITE_JPEG_QUALITY,75])[1],cv2.IMREAD_COLOR)[:,:,::-1].astype(np.float64)/255.0
                r_scj=selfcal.estimate_radius(bj)
                rows.append(dict(dataset=ds,image=iid,kernel_type=kt,kernel_param=p,noise=noise,r_true=rt,
                  r_evt=r_ev,r_selfcal=r_sc,r_fixed=r_fx,r_autocorr=r_ac,r_spectral=r_sp,r_svr=r_sv,
                  r_svr_tuned=r_st,r_svr_big=r_sb,r_selfcal_jpeg=r_scj,d1=d1,d2=d2,
                  t_evt=t_ev,t_selfcal=t_sc,t_fixed=t_fx,t_autocorr=t_ac,t_spectral=t_sp,t_svr=t_sv))
    print(ds,iid,len(rows),flush=True)
pd.DataFrame(rows).to_csv(out,index=False)
