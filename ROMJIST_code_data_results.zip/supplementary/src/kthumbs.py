from common import *
from PIL import Image
import numpy as np
ks={'kg':core.gaussian_kernel(5.0)[0],'kd':core.disk_kernel(7.0)[0] if isinstance(core.disk_kernel(7.0),tuple) else core.disk_kernel(7.0),'kl':core.motion_kernel(20,30)[0] if isinstance(core.motion_kernel(20,30),tuple) else core.motion_kernel(20,30)}
for n,k in ks.items():
    k=np.asarray(k,float); k=k/k.max(); h,w=k.shape; s=max(h,w); a=np.zeros((s,s)); a[(s-h)//2:(s-h)//2+h,(s-w)//2:(s-w)//2+w]=k
    Image.fromarray(((1-a)*255).astype(np.uint8)).resize((200,200),Image.NEAREST).save(BASE+'new/thumbs/'+n+'.png')
print('ok')
