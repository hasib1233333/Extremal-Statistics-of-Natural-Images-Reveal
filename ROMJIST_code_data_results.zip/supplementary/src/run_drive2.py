from common import *
import pandas as pd
from law import *
from PIL import Image
from skimage.transform import resize
C=json.load(open(BASE+'new/calib_params.json'))
files=sorted(glob.glob(BASE+'suppnew/data/drive_retina/*.tif')); print(len(files))
def load(p,dim=256):
    im=np.array(Image.open(p).convert('RGB')).astype(np.float64)/255.0
    s=dim/max(im.shape[:2]); 
    return resize(im,(int(im.shape[0]*s),int(im.shape[1]*s)),anti_aliasing=True) if s<1 else im
imgs=[load(f) for f in files]
sig_cal=[0.5,1,1.5,2,2.5,3,3.5,4,5,6,7,8,10,12]; sig_test=[1,2,3,4,5,6,8,10]
pk,dr=core.gaussian_kernel(sigma=PROBE_SIGMA)
# precompute depth curves and probe ratios for every image
cur=[];ratio=[];rtrue=[]
ks={s:core.gaussian_kernel(sigma=s) for s in sorted(set(sig_cal+sig_test))}
rc=np.array([0.0]+[ks[s][1] for s in sig_cal]); rtest=np.array([ks[s][1] for s in sig_test])
for im in imgs:
    cur.append([core.dark_channel_depth(im,5)[0]]+[core.dark_channel_depth(core.apply_blur(im,ks[s][0]),5)[0] for s in sig_cal])
    rr=[]
    for s in sig_test:
        b=core.apply_blur(im,ks[s][0]); d1=core.dark_channel_depth(b,5)[0]; d2=core.dark_channel_depth(core.apply_blur(b,pk),5)[0]; rr.append(d2/d1)
    ratio.append(rr)
cur=np.array(cur); ratio=np.array(ratio)
def split_eval(perm):
    ci,ei=perm[:20],perm[20:]
    d0,t,g=fit_law(rc,cur[ci].mean(0))
    e_rec=np.abs(invert(ratio[ei],t,g,dr)-rtest).mean(1)           # per held-out image
    e_nat=np.abs(invert(ratio[ei],C['tau'],C['gamma'],dr)-rtest).mean(1)
    return e_nat,e_rec,(t,g)
perm=np.random.default_rng(20260731).permutation(len(files))
e_nat,e_rec,(t,g)=split_eval(perm)
from scipy import stats
rng=np.random.default_rng(5); bs=[]
for _ in range(5000):
    i=rng.integers(0,20,20); bs.append(e_nat[i].mean()-e_rec[i].mean())
res=dict(n_images=len(files),tau_recal=t,gamma_recal=g,mae_nat=float(e_nat.mean()),mae_rec=float(e_rec.mean()),
  diff_ci=[float(np.percentile(bs,2.5)),float(np.percentile(bs,97.5))],wilcoxon_image_p=float(stats.wilcoxon(e_nat,e_rec).pvalue),
  n_instances=int(20*len(sig_test)),reduction_pct=float(100*(1-e_rec.mean()/e_nat.mean())))
# 200 random 20/20 splits for stability
r_=[]
for s in range(200):
    pm=np.random.default_rng(1000+s).permutation(len(files)); a,b,_=split_eval(pm); r_.append((a.mean(),b.mean()))
r_=np.array(r_); res['repeat_splits']=dict(n=200,mae_nat_mean=float(r_[:,0].mean()),mae_rec_mean=float(r_[:,1].mean()),frac_rec_better=float((r_[:,1]<r_[:,0]).mean()),mae_rec_p5_p95=[float(np.percentile(r_[:,1],5)),float(np.percentile(r_[:,1],95))])
# fixed default baseline on held-out images
res['mae_fixed3']=float(np.abs(3.0-rtest).mean())
json.dump(res,open(BASE+'new/drive2.json','w'),indent=1); print(json.dumps(res,indent=1))
