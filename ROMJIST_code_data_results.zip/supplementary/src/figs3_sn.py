from common import *
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'Liberation Sans','mathtext.fontset':'dejavusans','font.size':7.5,'axes.grid':True,'grid.linewidth':0.3,'figure.dpi':200})
o=json.load(open(BASE+'new/results/mp_stats.json'))
f,ax=plt.subplots(1,2,figsize=(5.17,3.29))
rc=o['_risk_coverage']; ax[0].plot(rc['cov'],rc['risk'],'k-',label='Keep lowest sensitivity $S(\\rho)$'); ax[0].axhline(2.64,color='k',ls=':',lw=0.8,label='No rejection (all instances)')
ax[0].set_xlabel('Fraction of instances kept'); ax[0].set_ylabel('MAE of kept instances (px)'); ax[0].set_title('(a) Sensitivity as a reliability score',loc='left',fontsize=8.5); ax[0].legend(fontsize=6.5); ax[0].set_ylim(1.8,3.0)
lc=o['_learning_curve']; ns=sorted(int(k) for k in lc)
ax[1].plot(ns,[lc[str(n)]['const'] for n in ns],'ks--',ms=3.5,mfc='none',lw=0.8,label='Tuned constant'); ax[1].plot(ns,[lc[str(n)]['shrink'] for n in ns],'ko-',ms=3.5,lw=0.8,label='Ours shrunk toward constant')
ax[1].axhline(2.64,color='0.4',ls=':',lw=0.8); ax[1].text(1.1,2.67,'ours, single probe',fontsize=6.5,color='0.3'); ax[1].axhline(1.82,color='0.4',ls='-.',lw=0.8); ax[1].text(1.1,1.84,'HOG+SVR tuned (25 img.)',fontsize=6.5,color='0.3')
ax[1].set_xscale('log'); ax[1].set_xlabel('Labelled images used to tune $(c,w)$'); ax[1].set_ylabel('MAE (px)'); ax[1].set_title('(b) Few labelled images suffice',loc='left',fontsize=8.5); ax[1].legend(fontsize=6.5,loc='center right'); ax[1].set_ylim(1.7,2.8)
f.tight_layout(); f.savefig(BASE+'new/figs_sn/W_reliability.pdf')
# qualitative success / failure
C=json.load(open(BASE+'new/calib_params.json')); sc=core.SelfCalibratingEVT(tau=C['tau'],gamma=C['gamma'],w=5,probe_sigma=PROBE_SIGMA)
fs=sorted(glob.glob(rk.DATASET_PATHS['Set14'])); IM=[rk.load_resized(f) for f in fs]
grid=[('gaussian',3.0),('gaussian',6.0),('disk',4.0),('disk',8.0),('motion',12.0),('motion',24.0)]
cand=[]
for ii,img in enumerate(IM):
    for kt,p in grid:
        k,rt=rk.build_kernel(kt,p,np.random.default_rng(1)); b=core.apply_blur(img,k); cand.append((abs(sc.estimate_radius(b)-rt),ii,kt,p,rt))
cand.sort(key=lambda x:x[0]); chosen=cand[:3]+cand[-3:]
fig,axs=plt.subplots(2,6,figsize=(5.17,3.54))
for j,(e,ii,kt,p,rt) in enumerate(chosen):
    img=IM[ii]; k,rt=rk.build_kernel(kt,p,np.random.default_rng(1)); b=core.apply_blur(img,k); rh=sc.estimate_radius(b)
    h,w=b.shape[:2]; cy,cx=h//2,w//2; s=min(64,h//2,w//2)
    axs[0,j].imshow(img[cy-s:cy+s,cx-s:cx+s]); axs[1,j].imshow(b[cy-s:cy+s,cx-s:cx+s])
    for a_ in axs[:,j]: a_.axis('off')
    axs[1,j].set_title('%s\n$r$=%.1f, $\\hat r$=%.1f'%({'gaussian':'Gaussian','disk':'Disk','motion':'Line'}[kt],rt,rh),fontsize=7)
    print(kt,p,rt,rh,ii)
fig.text(0.25,0.99,'Smallest errors',ha='center',va='top',fontsize=8); fig.text(0.75,0.99,'Largest errors',ha='center',va='top',fontsize=8)
fig.tight_layout(rect=(0,0,1,0.95)); fig.savefig(BASE+'new/figs_sn/X_examples.pdf')
