# Matched-covariance experiment: kernels with the SAME covariance matrix but different shapes.
from common import *
import pandas as pd
from scipy import linalg
C=json.load(open(BASE+'new/calib_params.json'))
sc=core.SelfCalibratingEVT(tau=C['tau'],gamma=C['gamma'],w=5,probe_sigma=PROBE_SIGMA)
SH=['Gaussian','Disk','Box','Ring','Laplace','Cross4','Triangle3']
SB=0.8
def cov(k):
    k=k/k.sum(); y,x=np.indices(k.shape).astype(float); cy=(k*y).sum(); cx=(k*x).sum()
    dx=x-cx; dy=y-cy
    return np.array([[(k*dx*dx).sum(),(k*dx*dy).sum()],[(k*dx*dy).sum(),(k*dy*dy).sum()]])
def render(shape,A,h,S=5):
    n=2*h+1; g=(np.arange(n*S)+0.5)/S-h-0.5  # supersampled coordinates, pixel centres at integers
    X,Y=np.meshgrid(g,g); P=np.stack([X.ravel(),Y.ravel()],0)
    if shape in('Cross4','Triangle3'):
        q=np.array([[1,0],[-1,0],[0,1],[0,-1]]).T if shape=='Cross4' else np.array([[np.cos(a),np.sin(a)] for a in (np.pi/2,np.pi/2+2*np.pi/3,np.pi/2+4*np.pi/3)]).T
        pos=A@q; f=np.zeros(P.shape[1])
        for i in range(pos.shape[1]): f+=np.exp(-((P[0]-pos[0,i])**2+(P[1]-pos[1,i])**2)/(2*SB**2))
    else:
        U=np.linalg.solve(A,P); r=np.hypot(U[0],U[1])
        if shape=='Gaussian': f=np.exp(-0.5*r**2)
        elif shape=='Disk': f=(r<=1).astype(float)
        elif shape=='Box': f=((np.abs(U[0])<=1)&(np.abs(U[1])<=1)).astype(float)
        elif shape=='Ring': f=((r>=0.8)&(r<=1)).astype(float)
        elif shape=='Laplace': f=np.exp(-r)
    f=f.reshape(n*S,n*S).reshape(n,S,n,S).mean((1,3)); return f/f.sum()
def make(shape,Sig_t,iters=6):
    ev=np.linalg.eigvalsh(Sig_t); h=int(min(60,np.ceil(5*np.sqrt(ev.max()))+3))
    Sh=linalg.sqrtm(Sig_t).real; A=Sh.copy()
    for it in range(iters):
        k=render(shape,A,h); Sn=cov(k)
        A=Sh@np.linalg.inv(linalg.sqrtm(Sn).real)@A
    k=render(shape,A,h); return k,cov(k)
def target(r,ratio):
    l1=r*r*ratio**2/(1+ratio**2); l2=r*r/(1+ratio**2); return np.diag([l1,l2])
classes={'iso':1.0,'ani2':2.0,'ani4':4.0}
set5,calib,unused,ev=pool_files()
sets=sorted(glob.glob(rk.DATASET_PATHS['Set14'])); bs=sorted(glob.glob(rk.DATASET_PATHS['BSD100']))
rng0=np.random.default_rng(555); cand=[f for f in bs if f not in set(calib) and 'img_' in f]
sel=sets+list(rng0.choice(cand,size=16,replace=False))
imgs=[(os.path.basename(f),rk.load_resized(f)) for f in sel]
def d12(b):
    d1=core.dark_channel_depth(b,5)[0]; d2=core.dark_channel_depth(core.apply_blur(b,sc._probe_kernel),5)[0]; return d1,d2
rows=[];kern={};err=[]
for r in (4,8):
    for cn,ratio in classes.items():
        St=target(r,ratio)
        for sh in SH:
            k,Sn=make(sh,St); e=np.linalg.norm(Sn-St)/np.linalg.norm(St); err.append(e)
            kern[f'{sh}_{cn}_{r}']=k
            for iid,im in imgs:
                b=core.apply_blur(im,k); d1,d2=d12(b)
                rows.append(dict(shape=sh,cls=cn,r=r,image=iid,rho=d2/d1,r_hat=sc.estimate_radius(b),cov_err=e))
        print('done',r,cn,flush=True)
pd.DataFrame(rows).to_csv(BASE+'new/cov_matched.csv',index=False)
np.savez(BASE+'new/cov_kernels.npz',**kern)
print('max cov error',max(err),'mean',np.mean(err))
