from common import *
import pickle, json
from law import *
P=pickle.load(open(BASE+'new/pool.pkl','rb')); n25=P['n_set5']+P['n_calib']
g=P['fam']['gaussian']; r=g['r']; d=g['depth'][:n25].mean(0)
d0,tau,gam=fit_law(r,d)
res=dict(delta0=d0,tau=tau,gamma=gam,w=5,r=list(r),delta=list(d))
json.dump(res,open(BASE+'new/calib_params.json','w'),indent=1); print(res['delta0'],tau,gam, 'rmax_r',r.max())
