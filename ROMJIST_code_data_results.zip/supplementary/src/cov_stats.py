import pandas as pd,numpy as np,json
from scipy import stats
d=pd.read_csv('cov_matched.csv'); out={}
print(d.groupby(['cls','r','shape']).cov_err.first().unstack().round(4))
d['k']=d.groupby(['cls','r','shape']).cumcount()
for (c,r),g in d.groupby(['cls','r']):
    P=g.pivot(index='k',columns='shape',values='rho')
    fr=stats.friedmanchisquare(*[P[s] for s in P.columns])
    rel=(P.max(1)-P.min(1))/P.mean(1)          # within-image shape spread
    btw=P.mean(1).std()/P.mean().mean()          # across-image CV
    m=P.mean(); 
    out[f'{c}_{r}']=dict(friedman_p=float(fr.pvalue),shape_spread_rel=float(rel.median()),image_cv=float(btw),
      shape_means={k:float(v) for k,v in m.items()},ratio_max_min=float(m.max()/m.min()))
    print(c,r,'p=%.1e'%fr.pvalue,'spread %.3f'%rel.median(),'imgCV %.3f'%btw,'mean-ratio %.3f'%(m.max()/m.min()))
    print((m/m.mean()).round(3).to_dict())
json.dump(out,open('cov_stats.json','w'),indent=1)
