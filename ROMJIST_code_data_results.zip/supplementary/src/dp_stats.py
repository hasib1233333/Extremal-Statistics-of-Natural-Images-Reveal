import glob,json,sys,numpy as np,pandas as pd
from scipy import optimize
from sklearn.ensemble import HistGradientBoostingRegressor as HGR, HistGradientBoostingClassifier as HGC
sys.path.insert(0,'../supp2/src'); import core
C=json.load(open('calib_params.json')); tau,gam=C['tau'],C['gamma']; RMAX=30.0
dp=pd.concat([pd.read_csv(f) for f in sorted(glob.glob('dp_*.csv'))],ignore_index=True)
mp=pd.concat([pd.read_csv(f) for f in sorted(glob.glob('mp_*.csv'))],ignore_index=True)
key=['dataset','image','kernel_type','kernel_param','noise']
m=dp.merge(mp[key+['d2_3','d2_5','d2_8']],on=key); assert len(m)==6432
m['img']=m.dataset+'/'+m.image; rt=m.r_true.values
for s in ('3','5','8'): m['l'+s]=np.log(np.clip(m['d2_'+s]/m.d1,1e-6,1))
for p in ('h','v','d45','d135'): m['l'+p]=np.log(np.clip(m['d2_'+p]/m.d1,1e-6,1))
ISO=['l3','l5','l8']; DIR=['lh','lv','ld45','ld135']
# single-probe estimate (frozen baseline)
dl=core.gaussian_kernel(sigma=5.0)[1]; c=(dl/tau)**2; rho=np.exp(m.l5.values); q=rho**(-1/gam)-1; u=np.maximum(c/q-1,0); base=np.minimum(tau*np.sqrt(u),RMAX); m['base']=base
# true anisotropy
tr=m.sxx+m.syy; det=m.sxx*m.syy-m.sxy**2; disc=np.sqrt(np.maximum((m.sxx-m.syy)**2/4+m.sxy**2,0)); l1=tr/2+disc; l2=tr/2-disc
m['A']=((l1-l2)**2/(tr**2+1e-12)); fam=m.kernel_type.map({'gaussian':0,'disk':1,'motion':2}).values
imgs=m.img.unique(); idx={i:np.where(m.img.values==i)[0] for i in imgs}; rng=np.random.default_rng(20261025); NREP=10
def xfit(fit_pred):
    acc={i:[] for i in imgs}
    for _ in range(NREP):
        p=rng.permutation(len(imgs)); A=[imgs[j] for j in p[:len(imgs)//2]]; B=[imgs[j] for j in p[len(imgs)//2:]]
        for tr_,te_ in ((A,B),(B,A)):
            tri=np.concatenate([idx[i] for i in tr_]); tei=np.concatenate([idx[i] for i in te_])
            e=np.abs(fit_pred(tri,tei)-rt[tei]); ii=m.img.values[tei]
            for i,v in pd.Series(e).groupby(ii): acc[i].append(float(v.mean()))
    return np.array([np.mean(acc[i]) for i in imgs])
def const(tri,tei): return np.full(len(tei),np.median(rt[tri]))
def shrink(tri,tei):
    cc=np.median(rt[tri]); ws=np.linspace(0,1,21); w=ws[int(np.argmin([np.abs(x*base[tri]+(1-x)*cc-rt[tri]).mean() for x in ws]))]; return w*base[tei]+(1-w)*cc
def gb(cols):
    X=m[cols].values
    def f(tri,tei):
        g=HGR(loss='absolute_error',max_iter=200,learning_rate=0.08,max_leaf_nodes=15,random_state=0).fit(X[tri],rt[tri]); return g.predict(X[tei])
    return f
res={}
res['Tuned constant']=xfit(const); res['Single probe + shrinkage']=xfit(shrink)
res['GB: isotropic probes (3)']=xfit(gb(ISO)); res['GB: directional probes (4)']=xfit(gb(DIR)); res['GB: isotropic + directional (7)']=xfit(gb(ISO+DIR))
m['d1']=m.d1; res['GB: iso + dir + amplitude d1']=xfit(gb(ISO+DIR+['d1']))
bs=np.random.default_rng(9); P=bs.integers(0,len(imgs),(2000,len(imgs)))
def ci(v): b=v[P].mean(1); return [float(np.percentile(b,2.5)),float(np.percentile(b,97.5))]
out={'regression':{}}
ref=res['GB: isotropic probes (3)']; ref2=res['Single probe + shrinkage']
for k,v in res.items():
    d=v-ref; d2=v-ref2; out['regression'][k]=dict(mae=float(v.mean()),ci=ci(v),vs_iso=dict(d=float(d.mean()),ci=ci(d)),vs_shrink=dict(d=float(d2.mean()),ci=ci(d2)))
    print(k,round(v.mean(),3),'vs iso GB',round(d.mean(),3),ci(d),'vs shrink',round(d2.mean(),3),ci(d2))
# anisotropy and family prediction (cross-fitted, image-level halves)
def cv_pred(cols,y,clf=False,reps=3):
    X=m[cols].values; pr=np.zeros(len(m)); cnt=np.zeros(len(m))
    for _ in range(reps):
        p=rng.permutation(len(imgs)); A=[imgs[j] for j in p[:len(imgs)//2]]; B=[imgs[j] for j in p[len(imgs)//2:]]
        for a,b in ((A,B),(B,A)):
            tri=np.concatenate([idx[i] for i in a]); tei=np.concatenate([idx[i] for i in b])
            g=(HGC(max_iter=150,random_state=0) if clf else HGR(max_iter=150,random_state=0)).fit(X[tri],y[tri]); pr[tei]+=g.predict(X[tei]); cnt[tei]+=1
    pr/=np.maximum(cnt,1); return pr
out['anisotropy']={}; y=m.A.values
for nm,cols in (('isotropic',ISO),('isotropic+directional',ISO+DIR)):
    pr=cv_pred(cols,y); r2=1-((pr-y)**2).sum()/((y-y.mean())**2).sum(); out['anisotropy'][nm]=dict(r2=float(r2),mae=float(np.abs(pr-y).mean())); print('anisotropy',nm,out['anisotropy'][nm])
out['anisotropy']['const_mae']=float(np.abs(y-np.median(y)).mean())
out['family']={}
for nm,cols in (('isotropic',ISO),('isotropic+directional',ISO+DIR)):
    X=m[cols].values; acc=[]
    for _ in range(3):
        p=rng.permutation(len(imgs)); A=[imgs[j] for j in p[:len(imgs)//2]]; B=[imgs[j] for j in p[len(imgs)//2:]]
        for a,b in ((A,B),(B,A)):
            tri=np.concatenate([idx[i] for i in a]); tei=np.concatenate([idx[i] for i in b]); g=HGC(max_iter=150,random_state=0).fit(X[tri],fam[tri]); acc.append(float((g.predict(X[tei])==fam[tei]).mean()))
    out['family'][nm]=float(np.mean(acc)); print('family acc',nm,out['family'][nm])
# --- determinant/anisotropy response model vs scalar model, using the true covariance ---
def covk(k):
    y_,x_=np.indices(k.shape); k=k/k.sum(); cy=(k*y_).sum(); cx=(k*x_).sum(); return np.array([[(k*(x_-cx)**2).sum(),(k*(x_-cx)*(y_-cy)).sum()],[(k*(x_-cx)*(y_-cy)).sum(),(k*(y_-cy)**2).sum()]])
def aniso(sx,sy,th):
    h=int(np.ceil(4*max(sx,sy))); y_,x_=np.mgrid[-h:h+1,-h:h+1].astype(float); t=np.deg2rad(th); u_=x_*np.cos(t)+y_*np.sin(t); v_=-x_*np.sin(t)+y_*np.cos(t); k=np.exp(-0.5*((u_/sx)**2+(v_/sy)**2)); return k/k.sum()
PC={'l3':covk(core.gaussian_kernel(sigma=3.0)[0]),'l5':covk(core.gaussian_kernel(sigma=5.0)[0]),'l8':covk(core.gaussian_kernel(sigma=8.0)[0])}
for nm,th in (('lh',0),('lv',90),('ld45',45),('ld135',135)): PC[nm]=covk(aniso(6,0.7,th))
t2=tau**2/2
def logF(S,eta):
    ev=np.linalg.eigvalsh(S+1e-12*np.eye(2)); l1_,l2_=ev[1],ev[0]; ld=np.log(1+l1_/t2)+np.log(1+l2_/t2); A_=((l1_-l2_)**2)/((l1_+l2_)**2+1e-9)
    return -0.5*gam*ld-eta*A_
S0=np.array([[[a,b],[b,d]] for a,d,b in zip(m.sxx,m.syy,m.sxy)])
cols=ISO+DIR
def pred(eta,rows):
    P_=np.zeros((len(rows),len(cols)))
    for ii,r_ in enumerate(rows):
        base_=logF(S0[r_],eta)
        for jj,cn in enumerate(cols): P_[ii,jj]=logF(S0[r_]+PC[cn],eta)-base_
    return P_
sub=np.arange(0,len(m),3)  # subsample for speed
Y=m[cols].values[sub]
half=np.isin(m.img.values[sub],imgs[::2]); fit=np.where(half)[0]; tst=np.where(~half)[0]
def rms(eta,ix,cs=None):
    Pm=pred(eta,sub[ix]); r_=Pm-Y[ix]; 
    return float(np.sqrt((r_**2).mean())) if cs is None else float(np.sqrt((r_[:,cs]**2).mean()))
etas=np.linspace(-3,3,25); sc=[rms(e,fit) for e in etas]; eta=float(etas[int(np.argmin(sc))])
iso_ix=[0,1,2]; dir_ix=[3,4,5,6]
out['response_model']=dict(eta_fit=eta,rms_eta0_test=rms(0.0,tst),rms_eta_test=rms(eta,tst),rms_eta0_test_iso=rms(0.0,tst,iso_ix),rms_eta_test_iso=rms(eta,tst,iso_ix),rms_eta0_test_dir=rms(0.0,tst,dir_ix),rms_eta_test_dir=rms(eta,tst,dir_ix))
# per-family, directional probes
for k_,f_ in (('gaussian',0),('disk',1),('motion',2)):
    ix=[i for i in tst if fam[sub[i]]==f_]; out['response_model']['dir_rms_eta0_'+k_]=rms(0.0,ix,dir_ix); out['response_model']['dir_rms_eta_'+k_]=rms(eta,ix,dir_ix)
# empirical: measured directional-probe ratio spread for line kernels vs orientation of the kernel
mot=m[m.kernel_type=='motion'].copy(); ang=0.5*np.arctan2(2*mot.sxy,mot.sxx-mot.syy)  # principal axis orientation of kernel
mot['ang']=np.rad2deg(ang)
out['response_model']['line_h_minus_v_logrho_corr_with_cos2theta']=float(np.corrcoef(mot.lh-mot.lv,np.cos(2*ang))[0,1])
def scal(rows):
    P_=np.zeros((len(rows),len(cols)))
    for ii,r_ in enumerate(rows):
        t0=np.trace(S0[r_])
        for jj,cn in enumerate(cols): P_[ii,jj]=-gam*(np.log(1+(t0+np.trace(PC[cn]))/tau**2)-np.log(1+t0/tau**2))
    return P_
Ps=scal(sub[tst]); rs=Ps-Y[tst]
out['response_model']['rms_scalar_test']=float(np.sqrt((rs**2).mean())); out['response_model']['rms_scalar_test_iso']=float(np.sqrt((rs[:,iso_ix]**2).mean())); out['response_model']['rms_scalar_test_dir']=float(np.sqrt((rs[:,dir_ix]**2).mean()))
json.dump(out,open('results/dp_stats.json','w'),indent=1); print(json.dumps(out['response_model'],indent=1))
