import sys, json, math, glob, numpy as np, pandas as pd
from scipy import stats
B=__import__('os').environ.get('RP_BASE','.').rstrip('/')+'/new/'
df=pd.concat([pd.read_csv(B+'up_%s.csv'%d) for d in ['Set14','BSD100','Urban100','CBSD68']],ignore_index=True)
df.to_csv(B+'results/kernel_size_ALL.csv',index=False)
M=['r_selfcal','r_evt','r_fixed','r_autocorr','r_spectral','r_svr','r_svr_tuned','r_svr_big']
NAME={'r_selfcal':'Probe-ratio EVT (ours)','r_evt':'Naive population-$\\Delta_0$ EVT','r_fixed':'Fixed default ($r=3$)',
 'r_autocorr':'Gradient autocorrelation','r_spectral':'Spectral-slope cutoff','r_svr':'HOG+SVR (25 images, fixed hyperparameters)',
 'r_svr_tuned':'HOG+SVR (25 images, CV-tuned)','r_svr_big':'HOG+SVR (65 images, 3 families, CV-tuned)'}
for m in M: df['e_'+m]=(df[m]-df.r_true).abs(); df['s_'+m]=(df[m]-df.r_true)**2
df['img']=df.dataset+'/'+df.image
imgs=df.img.unique(); N=len(imgs); ix={i:np.where(df.img.values==i)[0] for i in imgs}
rng=np.random.default_rng(20261023); Bt=2000
picks=[rng.integers(0,N,N) for _ in range(Bt)]
def boot_inst(fn):   # cluster bootstrap over images for an instance-level statistic
    out=[]
    for p in picks: out.append(fn(np.concatenate([ix[imgs[j]] for j in p])))
    return list(np.percentile(out,[2.5,97.5]))
res={'n_inst':len(df),'n_img':N,'mae':{},'comp':{}}
for m in M:
    E=df['e_'+m].values; S=df['s_'+m].values; x=df[m].values; y=df.r_true.values
    res['mae'][m]=dict(mae=E.mean(),mae_ci=boot_inst(lambda ii:E[ii].mean()),rmse=math.sqrt(S.mean()),rmse_ci=boot_inst(lambda ii:math.sqrt(S[ii].mean())),
      pearson=(np.corrcoef(x,y)[0,1] if x.std()>0 else float('nan')),pr_ci=boot_inst(lambda ii:np.corrcoef(x[ii],y[ii])[0,1]) if x.std()>0 else [float('nan')]*2,
      bias=float((x-y).mean()))
# image-level paired comparisons (PRIMARY)
Eimg=df.groupby('img')[['e_'+m for m in M]].mean()
ps=[];names=[m for m in M if m!='r_selfcal']
for m in names:
    d=(Eimg['e_r_selfcal']-Eimg['e_'+m]).values
    w=stats.wilcoxon(d); nz=d[d!=0]; rk_=stats.rankdata(np.abs(nz)); rb=(rk_[nz<0].sum()-rk_[nz>0].sum())/rk_.sum()
    bs=[d[p].mean() for p in picks]
    dinst=(df['e_r_selfcal']-df['e_'+m]).values; wi=stats.wilcoxon(dinst)
    res['comp'][m]=dict(mean_diff=d.mean(),ci=list(np.percentile(bs,[2.5,97.5])),p_img=w.pvalue,rb_img=rb,win_img=float((d<0).mean()),
                        dz=d.mean()/d.std(ddof=1),p_inst=wi.pvalue)
    ps.append(w.pvalue)
order=np.argsort(ps);k=len(ps);adj=[0]*k;run=0
for rank,i in enumerate(order): run=max(run,(k-rank)*ps[i]);adj[i]=min(run,1)
for j,m in enumerate(names): res['comp'][m]['p_holm_img']=adj[j]
# bins
bins=[0,2,4,8,15]; df['bin']=pd.cut(df.r_true,bins,right=False)
res['bins']={str(b):{**{m:dict(mae=s['e_'+m].mean(),n=len(s)) for m in M}} for b,s in df.groupby('bin',observed=True)}
res['per_ds']={ds:{k:{m:s[s.kernel_type==k]['e_'+m].mean() for m in M} for k in ['gaussian','disk','motion']} for ds,s in df.groupby('dataset')}
res['per_family']={k:{m:s['e_'+m].mean() for m in M} for k,s in df.groupby('kernel_type')}
res['per_noise']={str(k):{m:s['e_'+m].mean() for m in M} for k,s in df.groupby('noise')}
res['jpeg']={str(k):dict(mae=s['e_r_selfcal'].mean(),mae_jpeg=(s['r_selfcal_jpeg']-s['r_true']).abs().mean()) for k,s in df.groupby('noise')}
res['clamp_low']=float((df.r_selfcal<=1e-9).mean()); res['clamp_up']=float((df.r_selfcal>=30-1e-9).mean())
cl={}
for nz,s in df.groupby('noise'): cl[str(nz)]=float((s.r_selfcal<=1e-9).mean())
res['clamp_low_noise']=cl
res['time_ms']={m:float(df['t_'+t].mean()*1e3) for m,t in [('r_selfcal','selfcal'),('r_evt','evt'),('r_fixed','fixed'),('r_autocorr','autocorr'),('r_spectral','spectral'),('r_svr','svr')]}
json.dump(res,open(B+'results/stats.json','w'),indent=1,default=float)
def pv(p):
    if p<1e-300:return '$<10^{-300}$'
    e=int(math.floor(math.log10(p)));return '$%.1f\\times10^{%d}$'%(p/10**e,e)
def f2(x):return '%.2f'%x
# table_ci
rows=[]
for m in M:
    v=res['mae'][m]; pr='--' if math.isnan(v['pearson']) else '%.3f [%.3f, %.3f]'%(v['pearson'],*v['pr_ci'])
    rows.append('%s & %.2f [%.2f, %.2f] & %.2f [%.2f, %.2f] & %s \\\\'%(NAME[m],v['mae'],*v['mae_ci'],v['rmse'],*v['rmse_ci'],pr))
open(B+'tex/table_ci.tex','w').write('\\begin{tabular}{lccc}\n\\toprule\nMethod & MAE (px) & RMSE (px) & Pearson $r$ \\\\\n\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\n\\end{tabular}\n')
# table_paired (image-level primary)
rows=[]
for m in names:
    c=res['comp'][m]; rows.append('%s & %+.2f [%+.2f, %+.2f] & %s & %.2f & %.1f\\%% \\\\'%(NAME[m],c['mean_diff'],*c['ci'],pv(c['p_holm_img']),c['rb_img'],100*c['win_img']))
open(B+'tex/table_paired.tex','w').write('\\begin{tabular}{lcccc}\n\\toprule\nComparison (ours vs.) & $\\Delta$MAE [95\\% CI] (px) & Holm $p$ (image level) & $r_{rb}$ & Images where ours is closer \\\\\n\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\n\\end{tabular}\n')
# table_bins
bl=list(res['bins'].keys())
hdr=' & '.join('$r\\in[%s)$'%b.strip('[)').replace('(','').replace(']','') for b in bl)
rows=['Method & '+' & '.join('$r\\in%s$'%b.replace('[','[').replace(')',')') for b in bl)+' \\\\',' & '+' & '.join('$n{=}%d$'%res['bins'][b]['r_selfcal']['n'] for b in bl)+' \\\\','\\midrule']
for m in M: rows.append(NAME[m]+' & '+' & '.join(f2(res['bins'][b][m]['mae']) for b in bl)+' \\\\')
open(B+'tex/table_bins.tex','w').write('\\begin{tabular}{l'+'c'*len(bl)+'}\n\\toprule\n'+'\n'.join(rows[:3])+'\n'+'\n'.join(rows[3:])+'\n\\bottomrule\n\\end{tabular}\n')
# table3 per dataset x family
short=['r_selfcal','r_evt','r_fixed','r_autocorr','r_spectral','r_svr','r_svr_tuned','r_svr_big']
rows=[]
for ds in ['Set14','BSD100','Urban100','CBSD68']:
    for k in ['gaussian','disk','motion']:
        v=[res['per_ds'][ds][k][m] for m in short]; mn=min(v)
        rows.append('%s & %s & '%(ds,k)+' & '.join(('\\textbf{%.2f}'%x if x==mn else '%.2f'%x) for x in v)+' \\\\')
open(B+'tex/table3.tex','w').write('\\begin{tabular}{llcccccccc}\n\\toprule\nDataset & Kernel & Ours & Naive & Fixed & Autocorr. & Spectral & SVR & SVR-tuned & SVR-big \\\\\n\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\n\\end{tabular}\n')
# table6 runtime
rows=['%s & %.2f \\\\'%(NAME[m],res['time_ms'][m]) for m in ['r_selfcal','r_evt','r_fixed','r_autocorr','r_spectral','r_svr']]
open(B+'tex/table6.tex','w').write('\\begin{tabular}{lc}\n\\toprule\nMethod & Mean wall-clock time per image (ms) \\\\\n\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\n\\end{tabular}\n')
# table7 noise
rows=['%s & %.2f & %.2f \\\\'%(NAME[m],res['per_noise']['0.0'][m],res['per_noise']['0.02'][m]) for m in M]
open(B+'tex/table7.tex','w').write('\\begin{tabular}{lcc}\n\\toprule\nMethod & MAE, $\\sigma_{n}{=}0$ & MAE, $\\sigma_{n}{=}0.02$ \\\\\n\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\n\\end{tabular}\n')
print(json.dumps({m:{k:(round(v,3) if isinstance(v,float) else v) for k,v in res['mae'][m].items()} for m in M},indent=0)[:2500])
for m in names: print(m,{k:(round(v,4) if isinstance(v,float) else v) for k,v in res['comp'][m].items()})
print(res['clamp_low'],res['clamp_up'],res['clamp_low_noise'],res['jpeg'],res['time_ms'])
for b in bl: print(b,{m:round(res['bins'][b][m]['mae'],2) for m in M})
