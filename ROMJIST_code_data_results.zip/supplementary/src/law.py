import numpy as np
from scipy import optimize
def model(r,d0,tau,gam): return d0*(1+(r/tau)**2)**(-gam)
def fit_law(r,d,bounds=([1e-6,1e-3,1e-3],[1.0,100.0,20.0])):
    r=np.asarray(r,float); d=np.asarray(d,float)
    popt,_=optimize.curve_fit(model,r,d,p0=[d[0],3.0,1.0],bounds=bounds,maxfev=40000)
    return popt
def rho_pred(r,tau,gam,delta): return (1+(delta**2/tau**2)/(1+r**2/tau**2))**(-gam)
def invert(rho,tau,gam,delta,rmax=30.0):
    rho=np.clip(rho,1e-6,1-1e-6); q=rho**(-1/gam)-1
    u=np.maximum((delta**2/tau**2)/q-1,0); return np.minimum(tau*np.sqrt(u),rmax)
