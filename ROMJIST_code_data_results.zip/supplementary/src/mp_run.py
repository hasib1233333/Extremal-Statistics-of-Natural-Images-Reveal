# Multi-probe measurements: depth d1 of the observed image and d2(sigma_p) after several probe blurs,
# on exactly the same 6432 instances as run_all.py (same rng sequence).
from common import *
import pandas as pd
ds=sys.argv[1]; out=sys.argv[2]
PS=[3.0,5.0,8.0]
PK={s:core.gaussian_kernel(sigma=s) for s in PS}
rng=np.random.default_rng(rk.RNG_SEED)
set5,calib,unused,ev=pool_files(); bsd_calib=set(calib)
files=sorted(glob.glob(rk.DATASET_PATHS[ds]))
if ds=='BSD100': files=[f for f in files if f not in bsd_calib]
n=rk.N_SAMPLE[ds]
if n is not None and n<len(files):
    idx=rng.choice(len(files),size=n,replace=False); idx.sort(); files=[files[i] for i in idx]
grid={'gaussian':[1,2,3,4,5,6,8,10],'disk':[1,2,3,4,5,6,8,10],'motion':[3,6,9,12,15,18,24,30]}
rows=[]
for f in files:
    img=rk.load_resized(f); iid=os.path.basename(f)
    for kt,ps in grid.items():
        for p in ps:
            k,rt=rk.build_kernel(kt,p,rng)
            for noise in (0.0,0.02):
                b=core.apply_blur(img,k,noise_sigma=noise,rng=rng)
                row=dict(dataset=ds,image=iid,kernel_type=kt,kernel_param=p,noise=noise,r_true=rt,d1=core.dark_channel_depth(b,5)[0])
                for s in PS:
                    row['d2_%g'%s]=core.dark_channel_depth(core.apply_blur(b,PK[s][0]),5)[0]
                rows.append(row)
    print(ds,iid,len(rows),flush=True)
pd.DataFrame(rows).to_csv(out,index=False)
