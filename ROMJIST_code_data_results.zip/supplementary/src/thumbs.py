from common import *
import glob, json, numpy as np
from PIL import Image
import deconv
C=json.load(open(BASE+'new/calib_params.json'))
sc=core.SelfCalibratingEVT(tau=C['tau'],gamma=C['gamma'],w=5,probe_sigma=PROBE_SIGMA)
fs=sorted(glob.glob(rk.DATASET_PATHS['Set14']))
best=None
for f in fs:
    img=rk.load_resized(f); k,rt=rk.build_kernel('gaussian',4.0,np.random.default_rng(1)); b=core.apply_blur(img,k)
    e=abs(sc.estimate_radius(b)-rt)
    if best is None or e<best[0]: best=(e,f,img,b,k,rt)
e,f,img,b,k,rt=best; print(f,e,rt,sc.estimate_radius(b))
kp,_=rk.build_kernel('gaussian',PROBE_SIGMA/np.sqrt(2)*0+PROBE_SIGMA,np.random.default_rng(1)) if False else (core.gaussian_kernel(PROBE_SIGMA)[0],None)
bp=core.apply_blur(b,kp)
rh=sc.estimate_radius(b)
kh=deconv.assumed_kernel_from_radius(rh,'gaussian')
rest=np.clip(deconv.richardson_lucy(b,kh,n_iter=25),0,1)
h,w=b.shape[:2]; s=int(min(h,w)*0.7); y0=(h-s)//2; x0=(w-s)//2
def crop(a): return a[y0:y0+s,x0:x0+s]
def save(name,a):
    a=np.clip(a,0,1)
    if a.ndim==2: a=np.stack([a]*3,-1)
    Image.fromarray((a*255).astype(np.uint8)).resize((300,300),Image.LANCZOS).save(BASE+'new/thumbs/'+name+'.png')
save('B',crop(b)); save('Bp',crop(bp)); save('rest',crop(rest))
dc=lambda x: core.dark_channel_map(x,5)
save('dcB',crop(dc(b))); save('dcBp',crop(dc(bp)))
json.dump({'file':f,'rt':float(rt),'rh':float(rh)},open(BASE+'new/thumbs/info.json','w'))

import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'Liberation Serif','mathtext.fontset':'stix','font.size':8})
tau,gam=C['tau'],C['gamma']; dl=core.effective_radius(kp); c=dl**2/tau**2
r=np.linspace(0,16,400); rho=(1+c/(1+r**2/tau**2))**(-gam)
f,ax=plt.subplots(figsize=(1.9,1.45))
ax.plot(r,rho,'k-',lw=1)
ax.set_xlabel('$r$ (px)',fontsize=7,labelpad=1); ax.set_ylabel(r'$\rho$',fontsize=8,labelpad=1)
rr=rh; rv=(1+c/(1+rr**2/tau**2))**(-gam)
ax.plot([rr,rr,0],[0,rv,rv],'k--',lw=0.6); ax.plot([rr],[rv],'ko',ms=3)
ax.set_xlim(0,16); ax.set_ylim(0.6,1.0); ax.tick_params(labelsize=6,length=2,pad=1)
for sp in ('top','right'): ax.spines[sp].set_visible(False)
f.tight_layout(pad=0.2); f.savefig(BASE+'new/thumbs/law.pdf')
