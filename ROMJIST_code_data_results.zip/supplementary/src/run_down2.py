# Corrected downstream study: radius estimated from the very image that is restored;
# estimate converted to kernel parameters with the exact family relations.
from common import *
import pickle, pandas as pd
from scipy.signal import fftconvolve
import deconv
ds = sys.argv[1]; out = sys.argv[2]
C = json.load(open(BASE + 'new/calib_params.json')); S = pickle.load(open(BASE + 'new/svr.pkl', 'rb'))
selfcal = core.SelfCalibratingEVT(tau=C['tau'], gamma=C['gamma'], w=5, probe_sigma=PROBE_SIGMA)
naive = core.EVTCalibration(w=5); naive.delta0, naive.tau, naive.gamma = C['delta0'], C['tau'], C['gamma']
DIM = 256; NIT = 60


def svr_pred(m, b):
    return float(max(m.predict(core.hog_features(b).reshape(1, -1))[0], 0.0))


def kernel_from_r(r, fam):
    r = max(r, 0.3)
    if fam == 'gaussian':
        k, _ = core.gaussian_kernel(sigma=r / np.sqrt(2))
    elif fam == 'disk':
        k, _ = core.disk_kernel(radius=np.sqrt(2) * r)
    else:
        k, _ = core.motion_kernel(length=max(np.sqrt(12) * r, 1.0), angle_deg=0.0)
    if k.shape[0] > 61:
        k, _ = core.gaussian_kernel(sigma=r / np.sqrt(2), ksize=61)
    return k


M=16   # border margin excluded from all restoration metrics


def blur_reflect(img, k):
    ph, pw = k.shape[0] // 2, k.shape[1] // 2
    p = np.pad(img, ((ph, ph), (pw, pw), (0, 0)), mode='reflect')
    return np.clip(np.stack([fftconvolve(p[:, :, c], k, mode='valid') for c in range(3)], 2), 0, 1)


def crop(a):
    return a[M:-M, M:-M]


def rl_path(blurry, sharp, k, keep):
    k = k / (k.sum() + 1e-12); kf = k[::-1, ::-1]
    ph, pw = k.shape[0] // 2, k.shape[1] // 2
    P = np.pad(blurry, ((ph, ph), (pw, pw), (0, 0)), mode='reflect'); est = P.copy(); ps = []; kept = {}
    for it in range(1, NIT + 1):
        for c in range(3):
            conv = fftconvolve(est[:, :, c], k, mode='same') + 1e-6
            est[:, :, c] = np.clip(est[:, :, c] * fftconvolve(P[:, :, c] / conv, kf, mode='same'), 0, 1)
        cur = est[ph:ph + blurry.shape[0], pw:pw + blurry.shape[1]]
        ps.append(core.psnr(crop(cur), crop(sharp)))
        if it in keep:
            kept[it] = cur.copy()
    return np.array(ps), kept


def wiener_reflect(blurry, k, balance=0.02):
    ph, pw = k.shape[0] // 2, k.shape[1] // 2
    P = np.pad(blurry, ((ph, ph), (pw, pw), (0, 0)), mode='reflect')
    out = deconv.wiener_deconv(P, k, balance=balance)
    return out[ph:ph + blurry.shape[0], pw:pw + blurry.shape[1]]


# reproduce the original image selection (one draw per dataset, fixed order, seed 777)
rng = np.random.default_rng(777)
sel = None
for d in ['Set14', 'BSD100', 'Urban100', 'CBSD68']:
    im = sorted(pd.read_csv(BASE + 'supp2/results/kernel_size_%s.csv' % d).image.unique())
    s = rng.choice(im, size=min(6, len(im)), replace=False)
    if d == ds:
        sel = s
strata = {'gaussian': [2, 5, 10], 'disk': [2, 5, 10], 'motion': [6, 15, 30]}
rows = []; paths = []; examples = {}
for iid in sel:
    f = [x for x in glob.glob(rk.DATASET_PATHS[ds]) if os.path.basename(x) == iid][0]
    sharp = rk.load_resized(f, dim=DIM)
    for fam, ps in strata.items():
        for p in ps:
            if fam == 'gaussian':
                kt, rt = core.gaussian_kernel(sigma=p)
            elif fam == 'disk':
                kt, rt = core.disk_kernel(radius=p)
            else:
                kt, rt = core.motion_kernel(length=p, angle_deg=0.0)
            blurry = blur_reflect(sharp, kt)
            est = {'oracle': rt, 'selfcal': selfcal.estimate_radius(blurry), 'evt': naive.estimate_radius(blurry),
                   'fixed': core.baseline_fixed(blurry), 'autocorr': core.baseline_autocorrelation(blurry),
                   'spectral': core.baseline_spectral_slope(blurry), 'svr': svr_pred(S['svr_orig'], blurry),
                   'svr_tuned': svr_pred(S['svr_tuned'], blurry), 'svr_big': svr_pred(S['svr_big'], blurry)}
            row = dict(dataset=ds, image=iid, kernel_type=fam, kernel_param=p, r_true=rt,
                       psnr_blurry=core.psnr(crop(blurry), crop(sharp)), ssim_blurry=core.ssim(crop(blurry), crop(sharp)))
            pp = {}
            save_ex = (fam == 'gaussian' and p == 5 and iid == sel[0])
            if save_ex:
                examples[iid] = {'sharp': (sharp * 255).round().astype(np.uint8), 'blurry': (blurry * 255).round().astype(np.uint8)}
            for m, r in est.items():
                ka = kernel_from_r(r, fam)
                nad = int(np.clip(round(25 * (5.0 / max(r, 0.5)) ** 0.5), 3, 60))
                path, kept = rl_path(blurry, sharp, ka, {25, nad}); pp[m] = path
                wi = wiener_reflect(blurry, ka)
                row.update({f'rhat_{m}': r, f'psnr_{m}': path[24], f'ssim_{m}': core.ssim(crop(kept[25]), crop(sharp)),
                            f'psnr_w_{m}': core.psnr(crop(wi), crop(sharp)), f'ssim_w_{m}': core.ssim(crop(wi), crop(sharp)),
                            f'psnr_a_{m}': path[nad - 1], f'ssim_a_{m}': core.ssim(crop(kept[nad]), crop(sharp)), f'nad_{m}': nad,
                            f'kmse_{m}': deconv.kernel_mse(ka, kt)})
                if save_ex:
                    examples[iid][m] = (kept[25] * 255).round().astype(np.uint8)
            rows.append(row); paths.append(dict(image=iid, kernel_type=fam, kernel_param=p, paths=pp))
    print(ds, iid, len(rows), flush=True)
pd.DataFrame(rows).to_csv(out, index=False)
pickle.dump(dict(paths=paths, examples=examples), open(out.replace('.csv', '.pkl'), 'wb'))
