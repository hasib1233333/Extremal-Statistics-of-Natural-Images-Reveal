# Supplementary material

Submission to Multimedia Systems (Springer Nature). The Springer-width figures are made by the `*_sn.py` scripts in `src/`.

Manuscript: "Probe-Ratio Blur-Scale Estimation Using Extremal Image Statistics".

## Contents
- `src/core.py`, `src/deconv.py`: estimator (Algorithm 1), baselines, RL and Wiener solvers.
- `src/law.py`, `calib.py`, `run_pool.py`, `train_svr.py`: calibration (25 images, effective-radius abscissa), 65-image pool and the three HOG+SVR re-implementations.
- `src/run_all.py`: upstream evaluation (6432 instances, 134 images); `stats2.py`: image-level bootstrap, paired Wilcoxon, Holm.
- `src/calib_studies.py`, `probe_sens2.py`, `run_ms2.py`, `scale.py`, `run_drive2.py`: calibration size, law check, probe sweep, window ablation, runtime and resolution, DRIVE.
- `src/run_down2.py`, `down_stats2.py`: corrected downstream study (216 instances).
- `src/mp_run.py`, `mp_stats.py`: multi-probe measurements, reliability score, cross-fitted fallback and shrinkage, learning curve, prior-shift tests.
- `src/kern_exp.py`, `kern_stats.py`: matched-effective-radius kernels, Poisson-Gaussian/JPEG robustness, spatially varying blur.
- `src/dp_run.py`, `dp_stats.py`: directional-probe proof of concept (response-model test, incremental-information regression).
- `src/extras.py`, `boundary.py`: radius-distribution shift, joint multi-probe inversion, runtime profile, boundary-handling test.
- `src/down_extra.py`, `figs3.py`: PSNR gain versus radius error, per-image gains, reliability and example figures.
- `src/figs2.py`: remaining figures.
- `results/`: per-instance CSVs (`up_*.csv` upstream, `down_*.csv` downstream, and the rest) and summary JSONs behind every table and figure.
- `figures/`: the 24 figure PDFs as used in the manuscript.
- `tables/`: the LaTeX table bodies as used in the manuscript.

## Reproducing
The scripts were written against a working tree with `new/` (outputs), `work/` (datasets under `data/`) and `supp2/src` (core modules). Set `RP_BASE` to the root of such a tree. Datasets are public (links in the paper). Run in the order: `run_pool.py`, `calib.py`, `train_svr.py`, `run_all.py <dataset> up_<dataset>.csv`, `stats2.py`, `calib_studies.py`, `run_down2.py`, `down_stats2.py`, `run_ms2.py`, `scale.py`, `figs2.py`.

## Notes
- All baselines are re-implementations by the author, not code released by the original authors.
- HOG features use scikit-image when OpenCV's HOGDescriptor is unavailable.
- Absolute-path handling is minimal; expect to adjust paths. Timings depend on machine load.
- Results differ from the Research Square preprint because of corrected units and boundary handling (see the paper).

Software used: Python 3.13, NumPy 2.5, SciPy 1.18, scikit-learn 1.9, scikit-image 0.26, OpenCV 5.0, Pillow 12.3, Matplotlib 3.11.
